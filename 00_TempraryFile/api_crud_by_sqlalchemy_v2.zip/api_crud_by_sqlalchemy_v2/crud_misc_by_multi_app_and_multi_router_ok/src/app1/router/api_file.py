"""
概要: JsonFile model APIルータ
"""

# 標準ライブラリ
from __future__ import annotations
import shutil
import os
import tempfile
# 拡張ライブラリ
from fastapi import HTTPException, Depends, status, APIRouter, Path, File, UploadFile, Body
from sqlalchemy.orm import Session
from loguru import logger
# プライベートライブラリ
from common.db_crud.database import get_session
from common.db_crud.crud_file import JsonFile, JsonFileCrud
from app1.schema.schema_file import JsonFileResponse, JsonFileResponseBase, JsonFileQuery
from common.library import jsonfile2dict2
from common.config import API_PREFIX


# ------------------------------------------------------------
#  API ヘルパー関数
# ------------------------------------------------------------
def get_target_data(db: Session, target_id: int) -> JsonFile:
    """指定IDのデータ取得。指定IDのデータが見つからない場合、エクセプションを発生させる"""
    if (found_obj := JsonFileCrud.get(db, target_id=target_id)) is None:
        message = F"Invalid {target_id=}"
        logger.error(F"HTTP_404_NOT_FOUND:{message}")
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=message)
    return found_obj


def raise_400_name(name: str) -> None:
    """BAD_REQUESTエクセプションを発生"""
    message = F"{status.HTTP_400_BAD_REQUEST} Invalid name or Duplicate name:{name}"
    logger.error(F"HTTP_400_BAD_REQUEST:{message}")
    raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=message)


def convert_json_file(file: UploadFile) -> dict | list:
    """アップロードされたJSONファイルをpythonオブジェクトに変換。変換不能な場合、Exceptionとなる
    Args:
        file: ファイル情報
    Returns:
        変換結果(dict/list等）
    Note:
        JSONファイルのエンコードはUTF8のみをサポートする
    """
    if "json" not in file.content_type:
        message = F"Invalid Json:{file.content_type=}"
        logger.error(F"HTTP_400_BAD_REQUEST:{message}")
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=message)
    """
    try:
        # JSONファイルをdict形式に変換する(UTF8のみ変換可能)
        return json.load(file.file)
    except Exception as e:
        message = F"Invalid Json format or invalid encoding:{file.filename=}\t{file.content_type=}"
        logger.error(F"Exception:{type(e)}\tHTTP_400_BAD_REQUEST:{message}")
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=message)
    """
    # アップロードファイルの妥当性検証後にファイルを登録
    with tempfile.TemporaryDirectory() as temp_dir:
        # アップロードされたオブジェクトを一時ファイルにコピーして保存する
        temp_file_name = file.filename
        temp_file = os.path.join(temp_dir, temp_file_name)
        with open(temp_file, mode="wb") as of:
            shutil.copyfileobj(file.file, of)
        # 保存した一時ファイル(Shift-JIS/UTF8)を変換する
        try:
            res = jsonfile2dict2(json_file=temp_file)
            return res
        except Exception as e:
            message = F"Invalid Json:{file.filename=}\tException:{type(e)}"
            logger.error(F"HTTP_400_BAD_REQUEST:{message}")
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=message)


# -----------------------------------------------
#  API End point/APIルータ定義
# ポイント: APIRouterの定義によりモデル単位等の共通要素（パス名・タグ名等)定義が可能
# -----------------------------------------------
prefix = F"{API_PREFIX}/file"
router_file = APIRouter(prefix=prefix, tags=['JsonFile'])


@router_file.post("/query", summary="ファイル一覧検索", response_model=list[JsonFileResponseBase])
def query_files(
        session: Session = Depends(get_session),
        item: JsonFileQuery | None = Body(default=None, description="検索対象データ")
):
    """### JSONファイル一覧の絞り込み検索
    """
    logger.info(F"Start:{item=}")
    if item is None:
        item = JsonFileQuery()
    obj_list = JsonFileCrud.query(session, query_data=item)
    logger.success(F"End:{type(obj_list)}\tlen={len(obj_list)}")
    return obj_list


@router_file.post("/create", summary="ファイル登録", response_model=JsonFileResponse,
                  status_code=status.HTTP_201_CREATED)
def create_file(
        session: Session = Depends(get_session),
        file: UploadFile = File(default=..., description="アップロードファイル"),
):
    """### JSONファイルの新規登録（アップロード）

    **Notes**
    - 登録名がDBに登録済の場合、エラーを返す
    - 登録ファイルがJSONファイル(UTF8エンコーディング)でない場合、エラーを返す
    """
    logger.info(F"Start:{file.filename=}\t{file.content_type=}\tfile_body={type(file.file)}")
    file_body = convert_json_file(file)
    new_obj = JsonFileCrud.create(session, filename=file.filename, content_type=file.content_type, file_body=file_body)
    logger.success(F"End:{type(new_obj)}\t{new_obj}")
    return new_obj


@router_file.get("/{target_id}", summary="ファイル取得", response_model=JsonFileResponse | None)
def get_file_by_id(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1),
):
    """### 指定ファイル(target_id)を取得

    **Notes**
    - 指定データが見つからない場合、None(null)を返す
    """
    logger.info(F"Start:{target_id=}")
    found_obj = JsonFileCrud.get(session, target_id=target_id)
    logger.success(F"End:{type(found_obj)}\t{found_obj}")
    return found_obj


@router_file.delete("/{target_id}", summary="ファイル削除(by id)", response_model=JsonFileResponse)
def delete_file(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1),
):
    """### 指定ファイル(target_id)の削除

    **Notes**
    - 指定データが見つからない場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}")
    found_obj = get_target_data(session, target_id)
    JsonFileCrud.delete(session, target_obj=found_obj)
    logger.success(F"End:{type(found_obj)}\t{found_obj}")
    return found_obj


@router_file.put("/{target_id}", summary="ファイル更新", response_model=JsonFileResponse)
def update_file(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1),
        file: UploadFile = File(...),
):
    """### 指定ファイル(target_id)の更新

    **Notes**
    - 指定データが見つからない場合、エラーを返す
    - 更新後の名前が、DBに登録済の場合、エラーを返す
    - 登録ファイルがJSONファイル(UTF8エンコーディング)でない場合、エラーを返す
    """
    logger.info(F"Start:{file.filename=}\t{file.content_type=}\tfile_body={type(file.file)}")
    found_obj = get_target_data(session, target_id)
    # アップロードファイルの妥当性を検証
    file_body = convert_json_file(file)
    JsonFileCrud.update(session, target_obj=found_obj, filename=file.filename, content_type=file.content_type,
                        file_body=file_body)
    logger.success(F"End:{type(found_obj)}\t{found_obj}")
    return found_obj
