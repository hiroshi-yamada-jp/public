"""
概要: FastAPI CRUD: Mainサーバ for ALL
動作: Readme.md参照
Ref: https://fastapi.tiangolo.com/advanced/sub-applications/
"""

# 標準ライブラリ
import os.path
# 拡張ライブラリ
from fastapi import FastAPI
from loguru import logger
# プライベートライブラリ
from app1.router.api_file import router_file
from app1.router.api_item import router_item, router_admin_item

# ----------------------------------
#  API サーバ定義
# ----------------------------------
# 実行ファイル名から拡張子を除いたファイル名を取得し、appの起動名を生成する
name = os.path.splitext(os.path.basename(__file__))[0]
# ポイント: app名は以下のようにモジュール名:app名が正式な記載
app_name = F"{name}:app"

title = "API Sub-Server"
version = "V1.2025.0713"
description = """
### API機能
- Item: Item Model CRUD
- JsonFile Model CRUD
"""
# API共通の応答コード定義
responses = {
    404: {"description": "Not Found"},
    400: {"description": "Bad Request"},
    500: {"description": "Internal Server Error"},
}
app = FastAPI(title=title, description=description, version=version, responses=responses)

# -------------------------------------------------
# APIRouterの追加は全APIを定義後に、SwaggerUIの表示順を意識して行う
# -------------------------------------------------
app.include_router(router_item)
app.include_router(router_file)
app.include_router(router_admin_item,include_in_schema=True)


# サーバ起動エントリ
if __name__ == '__main__':
    import uvicorn

    host = "localhost"  # 公開する場合、"0.0.0.0"を使う
    port = 8001
    logger.debug(F"uvicorn.run(app={app_name},{host=},{port=})")
    uvicorn.run(app=app_name, host=host, port=port, reload=True)
