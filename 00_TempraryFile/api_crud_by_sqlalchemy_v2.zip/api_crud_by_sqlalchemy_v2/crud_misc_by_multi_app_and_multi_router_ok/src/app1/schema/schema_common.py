"""
概要: Common Schema
"""

from __future__ import annotations
# 標準ライブラリ
from datetime import datetime, timedelta, time
# 拡張ライブラリ
from pydantic import BaseModel, Field, model_validator


# -------------------------------------------------------------------------------------------
# APIパラメータ定義
# -------------------------------------------------------------------------------------------
class DatetimeRange(BaseModel):
    """検索用の日時範囲データ"""
    # デフォルトは、昨日の0時0分0秒から明日の0時0分0秒
    start: datetime = Field(default=datetime.combine(datetime.today().date(), time.min) - timedelta(days=1))
    end: datetime = Field(default=datetime.combine(datetime.today().date(), time.min) + timedelta(days=1))

    @model_validator(mode="after")
    def validate_relation(self):
        """二つのパラメータの相関検査を行うパターン
        @model_validator(mode="after")でインスタンス化されているので
        self.xxxで各パラメータをアクセスできる
        """
        if self.start > self.end:
            raise ValueError(F"Invalid range:{self}")
        # 元のパラメータ一式を返す
        return self


# ---------------------------------------------------------------
#  検証用関数定義
# ---------------------------------------------------------------
def get_effective_string(s_in: str, min_len: int = 1) -> str | None:
    """入力文字列を検査し、有効文字列の抽出。文字列長が規定未満の場合、エクセプションを返す。

    Args:
        s_in: 入力文字列
        min_len: 最小の有効文字列長
    Returns:
        str: 有効文字列 / None: 入力内容が文字列でない場合
    """
    if isinstance(s_in, str):
        if len(s_in.strip()) < min_len:
            raise ValueError(F"Invalid or too short parameter:{repr(s_in)} ")
        return s_in.strip()
    return None
