"""
概要: Config情報定義
"""

# 標準ライブラリ
from __future__ import annotations
import os
# 拡張ライブラリ
from dotenv import load_dotenv

load_dotenv()  # .envファイルからシークレット定義の読み込み
# ---------------------------------------------
#   共通
# ---------------------------------------------
API_VERSION = "v01"
API_PREFIX = F"/api/{API_VERSION}"
MAX_LENGTH = 64
MAX_LENGTH_L = 1024
# ---------------------------------------------
#   ロギング関係
# ---------------------------------------------
DEFAULT_LOG_LEVEL = "TRACE"  # "TRACE" | "DEBUG" | "INFO"
LOG_DIR = "logs"
LOG_FILE = F"{LOG_DIR}/server.log"  # ロギングファイル名
# ---------------------------------------------
#   DB関係
# ---------------------------------------------
SQLITE_MODE = True  # True: SQLITE DB  / False: Other RDB (MySQL or PostgreSQL)
# Note: メモリーモードに設定すると、各機能が正常動作しないので使わないこと
SQLITE_MEMORY_MODE = False  # True: SQLITE Memory DB / False: SQLITE File DB
DB_PATH = "sqlite_db"  # SQLite用のDBファイル格納先ディレクトリ

if SQLITE_MODE:
    if SQLITE_MEMORY_MODE:
        DB_URL = F"sqlite:///:memory:"
    else:
        db_name = "testdb.db"  # DBファイル名
        DB_URL = F"sqlite:///{DB_PATH}/{db_name}"
else:
    db_name = "testdb"  # DB名
    db_user = os.getenv("DB_USER")
    db_pwd = os.getenv("DB_PWD")
    db_host = 'localhost'
    DB_URL = F"mysql+mysqlconnector://{db_user}:{db_pwd}@{db_host}/{db_name}"
    # 参考：postgresqlの場合のURIとエンジン設定は、以下のように行えるはず
    # DB_URL = F"postgresql://{db_user}:{db_pwd}@{db_host}/{db_name}"
