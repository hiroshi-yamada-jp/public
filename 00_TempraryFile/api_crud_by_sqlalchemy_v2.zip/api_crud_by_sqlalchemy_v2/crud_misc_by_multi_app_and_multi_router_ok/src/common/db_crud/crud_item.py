"""
概要: Item Model CRUD CRUD (sqlalchemy 2.0)
参考：
- 【SQLAlchemy】Generic Typesと各種DBの型 対応表: https://zenn.dev/re24_1986/articles/8520ac3f9a0187
"""

# 標準ライブラリ
from __future__ import annotations
# 拡張ライブラリ
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy import and_, JSON, Boolean, Enum
# プライベートライブラリ
from common.db_crud.crud_abstract import AbstractCrud, AbstractModel
from app1.schema.schema_item import DeviceType
from app1.schema.schema_common import DatetimeRange


# -----------------------------------------------------------------------------------------
#  Model定義
# -----------------------------------------------------------------------------------------
class Item(AbstractModel):
    """DBモデル定義
        Notes: id,name,description,日時データは、抽象クラスから継承している点に注意
    """
    __tablename__ = 'item'  # テーブル名は任意

    protect_flag: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False, comment="bool型")
    device_type: Mapped[str] = mapped_column(Enum(DeviceType), default=DeviceType.UNDEFINE, comment="Enum型(str)")
    list_type: Mapped[list | None] = mapped_column(JSON, default=None, nullable=True, comment="リスト型")
    dict_type: Mapped[dict | None] = mapped_column(JSON, default=None, nullable=True, comment="辞書型")

    # 自動作成の作成・更新日時データの設定
    def __repr__(self):
        """データ内容の表示"""
        append_ab = F"id={self.id},name={repr(self.name)},description={repr(self.description)}"
        append = F"protect_flag={self.protect_flag},device_type={self.device_type}"
        append2 = F"list_type={self.list_type},dict_type={self.dict_type}"
        append_dt = F"created_at={self.created_at},updated_at={self.updated_at}"
        return F"<Item({append_ab},{append},{append2},{append_dt}>"


# -----------------------------------------------------------------------------------------
#  CRUD処理
# -----------------------------------------------------------------------------------------
class ItemCrud(AbstractCrud):
    """ITEM用CRUD処理
        Notes: 記述した以外の基本的なCRUDメソッドは、継承元をそのまま使っている点に注意
    """
    Model = Item

    @classmethod
    def set_filter(cls, *, name: str = None, updated_at: DatetimeRange = None):
        """query用のfilterデータの設定

        Args:
            name: 検索文字列を含むキーワード(LIKE検索)、Noneの場合は、絞り込みなし
            updated_at: 検索の更新時間レンジを含むキーワード、Noneの場合は、絞り込みなし
        Returns:
            list: 検索条件の設定リスト
        """
        # ポイント: 複数Queryを設定する汎用的な書き方
        filters = []
        if isinstance(name, str) and name.strip():
            filters.append(cls.Model.name.like(F"%{name}%"))  # 名前が一部一致の場合
        if updated_at is not None:
            filters.append(and_(
                cls.Model.updated_at >= updated_at.start,
                cls.Model.updated_at <= updated_at.end
            ))
        return filters
