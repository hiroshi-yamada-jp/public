"""
概要: SQlite DB定義 (sqlalchemy)
Notes: SQLAlchemy 2.0対応の書き方
 - FastAPI+SQLAlchemyで非同期WebAPI(https://www.rhoboro.com/2021/06/12/async-fastapi-sqlalchemy.html)
"""

# 標準ライブラリ
import os
# 拡張ライブラリ
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase
from dotenv import load_dotenv

# ---------------------------------------------
#  初期設定・ファンクション定義
# ---------------------------------------------
# .envファイルからシークレット定義の読み込み
load_dotenv()
db_echo = False  # DBログのエコーモード
# .envファイルが存在しない場合も、SQlite3を使う
SQLITE_MODE = False if os.getenv("SQLITE_MODE") == "0" else True
if SQLITE_MODE:
    db_path = "sqlite_db"  # DBファイル格納先
    db_name = "api_test.db"  # DBファイル名
    db_uri = F"sqlite:///{db_path}/{db_name}"
    db_engine = create_engine(db_uri, echo=db_echo, connect_args={"check_same_thread": False})
else:
    # 参考：postgresql/MySQLの場合のURIとエンジン設定は、以下のように行う
    DB_USER = os.getenv("DB_USER")
    DB_PWD = os.getenv("DB_PWD")
    DB_HOST = os.getenv("DB_HOST", default="localhost")
    DB_NAME = os.getenv("DB_NAME", default="testdb")
    # db_uri = F"postgresql://{DB_USER}:{DB_PWD}@{DB_HOST}/{DB_NAME}"
    db_uri = F"mysql+mysqlconnector://{DB_USER}:{DB_PWD}@{DB_HOST}/{DB_NAME}"
    # ポイント:
    # max_overflow:プールの最大オーバーフローサイズ(default=10) -1に設定するとpool数の制限はなくなる
    # pool_pre_ping:プールのコネクション時にpingでActive状態を確認するので、接続切れによるエラーを回避可能
    db_engine = create_engine(db_uri, echo=db_echo, max_overflow=10, pool_pre_ping=True)

# 以下の正確な動作は理解不足
SessionLocal = sessionmaker(bind=db_engine, autocommit=False, autoflush=False)


# ポイント: SQLAlchemy2.0 StyleのBase定義方法
class Base(DeclarativeBase):
    pass


def get_session():
    """各リクエスト毎のDBセッション管理"""
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()


# ポイント: オブジェクト化しなくても利用可能なクラス定義
class Database:
    """SQLite3用データベースクラス """

    @staticmethod
    def setup_db_table() -> None:
        """DB格納ディレクトリとDBテーブルの作成。作成済の場合は、何もしない"""
        if SQLITE_MODE:
            os.makedirs(db_path, exist_ok=True)
        Base.metadata.create_all(db_engine)

    @classmethod
    def initialize_all_table(cls) -> None:
        """データベース初期化: DB内のテーブルの初期化"""
        Base.metadata.drop_all(db_engine)
        cls.setup_db_table()

    @staticmethod
    def get_info() -> dict:
        """データベース設定情報の取得"""
        res = {
            "SQLITE_MODE": SQLITE_MODE,
            "db_engine": repr(db_engine),
            "db_engine.pool.status()": db_engine.pool.status(),
        }
        return res
