"""
概要: JsonFile Model & CRUD (sqlalchemy 2.0)
参考：
- Zenn:【SQLAlchemy】Generic Typesと各種DBの型 対応表: https://zenn.dev/re24_1986/articles/8520ac3f9a0187
"""

# 標準ライブラリ
from __future__ import annotations
from typing import Sequence
from datetime import datetime
# 拡張ライブラリ
from sqlalchemy.orm import Session, Mapped, mapped_column
from sqlalchemy import String, JSON, Integer, DateTime, asc, and_, select
# プライベートライブラリ
from common.db_crud.database import Base
from app1.schema.schema_file import JsonFileQuery

# -----------------------------------------------------------------------------------------
#  Model定義
# -----------------------------------------------------------------------------------------
# String型の最大文字列長 ※ MySQL ORMでは文字列長を規定しないと、正常動作しない
MAX_LENGTH = 64


class JsonFile(Base):
    """DBモデル定義"""
    __tablename__ = 'Jsonfile'  # テーブル名は任意
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True, unique=True, comment="ID(自動)")
    filename: Mapped[str] = mapped_column(String(MAX_LENGTH), default=..., nullable=False, comment="ファイル名")
    content_type: Mapped[str] = mapped_column(String(MAX_LENGTH), default="", comment="コンテンツタイプ")
    # JSON(dict)構造の設定
    file_body: Mapped[dict] = mapped_column(JSON, default={}, comment="ファイル内容")
    # 自動作成の作成・更新日時データの設定
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now, comment="作成日時（自動)")
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now, onupdate=datetime.now,
                                                 comment="更新日時（自動)")

    def __repr__(self):
        """データ内容の表示:ファイルコンテンツは、データ内容を表示しない点に注意"""
        append = F"content_type={self.content_type},file_body={type(self.file_body)}"
        append2 = F"created_at={self.created_at},updated_at={self.updated_at}"
        return F"<JsonFile(id={self.id},filename={repr(self.filename)},{append},{append2}>"


# -----------------------------------------------------------------------------------------
#  CRUD処理
# -----------------------------------------------------------------------------------------
class JsonFileCrud:
    """CRUD処理"""

    @staticmethod
    def query(db: Session, query_data: JsonFileQuery) -> Sequence[JsonFile]:
        """全登録データから検索条件に合致するデータリストをAND条件で抽出

        Args:
            db: DBセッション
            query_data: 検索条件
        Returns:
            検索結果の一覧リスト
        """
        # ポイント: 複数Queryを設定する汎用的な書き方
        filters = []
        if query_data.updated_at is not None:
            filters.append(and_(
                JsonFile.updated_at >= query_data.updated_at.start,
                JsonFile.updated_at <= query_data.updated_at.end
            ))
        if len(filters) == 0:
            stmt = select(JsonFile).order_by(asc(JsonFile.id))
            # stmt = select(JsonFile).order_by(desc(JsonFile.id))
        else:
            stmt = select(JsonFile).filter(and_(*filters)).order_by(asc(JsonFile.id))
            # stmt = select(JsonFile).filter(and_(*filters)).order_by(desc(JsonFile.id))
        # ポイント: 全件リストを取得する場合の書き方
        return db.execute(stmt).scalars().all()

    @staticmethod
    def get(db: Session, target_id: int) -> JsonFile | None:
        """指定IDのデータ取得

        Args:
            db: DBセッション
            target_id: 取得対象のID番号
        Returns:
            JsonFile:取得データ / None: データが見つからない
        """
        res = db.get(JsonFile, target_id)  # 2.0 Styleの書き方
        # res = JsonFile.query.get(target_id)   # Legacy 1.x Styleの書き方
        return res

    @staticmethod
    def delete(db: Session, target_obj: JsonFile) -> None:
        """指定データの削除

        Args:
            db: DBセッション
            target_obj: 操作対象のデータオブジェクト
        Returns:
            None
        """
        db.delete(target_obj)
        db.commit()

    @staticmethod
    def update(db: Session, target_obj: JsonFile, *, filename: str | None = None, content_type: str | None = None,
               file_body=None) -> JsonFile:
        """指定データの更新

        Args:
            db: DBセッション
            target_obj: 操作対象のデータオブジェクト
            filename: 更新後のファイル名 (文字列以外の場合、更新しない）
            content_type: 更新後のコンテンツタイプ (文字列以外の場合、更新しない）
            file_body: 更新後のファイル内容(Noneの場合、更新しない）
        Returns:
            JsonFile:更新データ
        """
        # ポイント: 各指定項目が有効型（本来はNone以外はありえない）でなければ、該当データを更新しない
        if isinstance(filename, str):
            target_obj.filename = filename
        if isinstance(content_type, str):
            target_obj.content_type = content_type
        if file_body is not None:
            target_obj.file_body = file_body
        db.commit()
        db.refresh(target_obj)
        return target_obj

    @staticmethod
    def create(db: Session, *, filename: str, content_type: str, file_body) -> JsonFile:
        """指定データの新規登録

        Args:
            db: DBセッション
            filename: ファイル名
            content_type: コンテンツタイプ
            file_body: ファイル内容
        Returns:
            JsonFile:登録データ
        """
        new_obj = JsonFile(filename=filename, content_type=content_type, file_body=file_body)
        db.add(new_obj)
        db.commit()
        return new_obj
