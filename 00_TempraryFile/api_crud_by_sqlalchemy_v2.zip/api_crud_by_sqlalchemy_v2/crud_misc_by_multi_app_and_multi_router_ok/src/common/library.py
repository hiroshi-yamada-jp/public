# --------------------------------
#  loggingの初期設定
# --------------------------------

# 標準ライブラリ
from __future__ import annotations
import json
from sys import stdout
# 拡張ライブラリ
from loguru import logger


def setup_loguru(log_level: str, *, log_file: str = "", rotation: str = "00:00", retention: str = "5 days") -> None:
    """ロギング情報の初期設定

    Args:
        log_level: ログレベルの設定 ("TRACE" | "DEBUG" | "INFO" )
        log_file: ログファイルの出力パス (空白文字の場合、ログファイル出力は無効となる)
        rotation: ログファイルのローテーション期間
        retention: ログファイルの保存期間
    """
    logger.remove()  # デフォルトのログをクリア
    # 出力フォーマット定義:レベル・モジュール・関数部はレベルに応じた色、メッセージは装飾なしに設定した例
    fmt1 = "<level>[SVR:{level}][{time:YYYY-MM-DD HH:mm:ss.SSSS}]:[{module}:{function}:{line}]:{message}</level>"
    # ディスプレイ出力用の設定
    logger.add(stdout, format=fmt1, level=log_level)
    # ファイル出力用設定：毎日指定時刻にローテートしてn世代分持つ、初期ディレクトリは自動作成される
    if log_file:
        logger.add(log_file, rotation=rotation, retention=retention, format=fmt1, level=log_level)


def jsonfile2dict(json_file: str, *, encoding: str = "utf_8") -> dict | list:
    """指定エンコードのJSONファイルをdict形式に変換する

    Args:
        json_file: JSONファイルパス
        encoding: JSONファイルのエンコーディング ("utf_8" | "utf_8_sig" | "cp932" )
    Returns:
        dict | list: 変換結果
    """
    with open(json_file, mode="r", encoding=encoding) as fin:
        return json.load(fin)


def jsonfile2dict2(json_file: str) -> dict | list:
    """JSONファイル(UTF-8 or Shift-JIS形式)をdict形式に変換する

    Args:
        json_file: JSONファイルパス
    Returns:
        dict | list: 変換結果
    """
    support_encoding_list = ["utf_8_sig", "cp932", "utf_8_sig"]
    for encoding in support_encoding_list:
        try:
            return jsonfile2dict(json_file, encoding=encoding)
        except Exception:
            continue
    raise UnicodeDecodeError
