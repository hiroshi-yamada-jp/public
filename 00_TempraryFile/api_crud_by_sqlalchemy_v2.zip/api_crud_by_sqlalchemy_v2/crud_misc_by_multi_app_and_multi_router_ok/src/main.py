"""
概要: FastAPI CRUD: Mainサーバ for ALL
動作: Readme.md参照
Ref: https://fastapi.tiangolo.com/advanced/sub-applications/
"""

# 標準ライブラリ
import os
import platform
from contextlib import asynccontextmanager
# 拡張ライブラリ
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
from loguru import logger
# プライベートライブラリ
from common.db_crud.database import Database
from common.library import setup_loguru
from fastapi_template.api_crud_by_sqlalchemy_v2.crud_misc_by_multi_app_and_multi_router_ok.src.router.api_admin import \
    router_admin
# プライベートライブラリ:統合アプリ
from app1.main1 import app as app1

# ----------------------------------
#  初期設定・クラス定義
# ----------------------------------
# プログラム全体のロギング設定
DEFAULT_LOG_LEVEL = "TRACE"  # "TRACE" | "DEBUG" | "INFO"
LOG_DIR = "logs"
os.makedirs(LOG_DIR, exist_ok=True)
LOG_FILE = F"{LOG_DIR}/server.log"  # ロギングファイル名
setup_loguru(log_level=DEFAULT_LOG_LEVEL, log_file=LOG_FILE)
Database.setup_db_table()

# ----------------------------------
#  API サーバ定義
# ----------------------------------
title = "API Server CRUD By SQLAlchemy2.0 for SQLite"
version = "V1.2025.0713"
description = F"""
### サーバ情報
- {platform.platform()=}
- {platform.node()=}

### API機能
- Admin:管理メニュー
- [app1 API menu](http://localhost:8000/app1/docs)
"""
# API共通の応答コード定義
responses = {
    404: {"description": "Not Found"},
    400: {"description": "Bad Request"},
    500: {"description": "Internal Server Error"},
}


# -------------------------------------------------
#  start-up/shutdown処理定義
#  - @app.on_event()は、deprecatedとなり、以下の書き方を行う
# -------------------------------------------------
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Start-up Event")
    yield
    logger.info("Shut-down Event")


app = FastAPI(title=title, description=description, version=version, responses=responses, lifespan=lifespan)

# 実行ファイル名から拡張子を除いたファイル名を取得し、appの起動名を生成する
name = os.path.splitext(os.path.basename(__file__))[0]
# ポイント: app名は以下のようにモジュール名:app名が正式な記載
app_name = F"{name}:app"

# -------------------------------------------------
#  CORS定義: ポイント
#  - Clientから利用するため、CORSを定義する
#  - mail_allで定義すれば、ここから追加されるアプリでは設定不要なはず
# -------------------------------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origin
    # allow_origins=origins,  # Allow specified origin
    allow_credentials=True,  # Allow cookies
    allow_methods=["*"],  # Allow all method
    allow_headers=["*"],
)

# -------------------------------------------------
# 本サーバ配下のAPIRouter追加
# -------------------------------------------------
app.include_router(router_admin, include_in_schema=True)  # Swagger表示制御

# -------------------------------------------------
# Sub API Applicationの追加
# ポイント: 追加APIサーバを新たなパス以下にマウントする
# -------------------------------------------------
app.mount("/app1", app1)


# -------------------------------------------------
#  共通エンドポイント
# -------------------------------------------------
@app.get("/", summary="Swagger UIへのリダイレクト(非表示)", include_in_schema=False)
def redirect():
    """Swagger UIへのリダイレクト処理"""
    url = "/docs"
    logger.info(F"Redirect to:{url}")
    return RedirectResponse(url=url)


# サーバ起動エントリ
if __name__ == '__main__':
    import uvicorn

    host = "localhost"  # 公開する場合、"0.0.0.0"を使う
    port = 8000
    logger.debug(F"uvicorn.run(app={app_name},{host=},{port=})")
    # コマンド起動の場合：uvicorn --host 0.0.0.0 --port 800x --reload main:app
    uvicorn.run(app=app_name, host=host, port=port, reload=True)
