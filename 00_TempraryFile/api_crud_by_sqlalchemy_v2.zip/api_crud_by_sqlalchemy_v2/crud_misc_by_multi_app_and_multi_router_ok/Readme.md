# FastAPI CRUD Template pattern#1

## 概要

FastAPI CRUDアプリ(API_Routerで各カテゴリ別に統合)

- DB: SQlite3 DB by sqlalchemy ver2.0 style
- Python: 3.10以降
- SQLAlchemy: 2.0以降
- Fastapi: 0.115以降
- 動作結果：OK @2025/06/14

### 機能

- Admin:管理メニュー
- User CRUD
- ITEM CRUD
- JsonFile CRUD

### 主要ライブラリ

- fastapi: pip install -U fastapi[all]
- sqlalchemy: pip install -U  sqlalchemy
- loguru: pip install -U  loguru
- bcrypt: pip install -U  bcrypt
- passlib: pip install -U  passlib
- python-jose: pip install -U  python-jose[cryptography]

### ファイル構成

```
TOP(src)ディレクトリ以下: これをソースルートとしてマーキングしないと、importエラーとしてpycharmで認識される
├─ main.py: APIサーバメインファイル
├─ env(.env): シークレット情報定義.envにリネームする)
├─ logs: ログファイルディレクトリ※ プログラムが動的に作成
├─ sqlite_db: SQLite DBファイルディレクトリ※ プログラムが動的に作成
├─ common: 共通ディレクトリ
    ├─ library.py: 共通ライブラリ
    ├─ db_crud: DB&DB_CRUD&Model用サブディレクトリ
        ├─ crud_file: file Model用CRUD処理
        ├─ crud_item: item Model用CRUD処理
        ├─ crud_user: user Model用CRUD処理
        ├─ database.py: DB定義
    ├─ router: 共通router用サブディレクトリ
        ├─ api_admin.py: admin用API
├─ app1: サブアプリ#1用のディレクトリ
    ├─ router: サブアプリ#1用のrouterディレクトリ
        ├─ api_file: file用API
        ├─ api_item: item用API
        ├─ api_user: user用API
    ├─ schema: サブアプリ#1用のAPIスキーマ定義ディレクトリ
        ├─ schema_file: file api用スキーマ定義
        ├─ schema_item: item api用スキーマ定義
        ├─ schema_user: user api用スキーマ定義
```

### 注意
1. 対象DBは、Sqlite3/MySQL8.x。但し、SQlite3のメモリモードは動作しない。
2. db_crudは、各アプリごとに定義することも可能だが、共通DBを利用するため、common配下に置いた
