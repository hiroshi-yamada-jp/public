"""
概要: Sample モデル用APIルータ
更新: 2025/11/14
"""

# 標準ライブラリ
from __future__ import annotations
# 拡張ライブラリ
from fastapi import Depends, APIRouter, Path, Body, Query
from sqlalchemy.orm import Session
from loguru import logger
# プライベートライブラリ
from db_crud.database import get_session
from db_crud.crud_abstract import Operand
from db_crud.crud_sample import SampleCrud, SampleModel
from schema.schema_sample import (SampleRegisterParams, SampleUpdateParams, SampleModelResponse)
from router.helper_api_common import ApiExceptionHelper
from common.library import get_effective_string


# -----------------------------------------------
#  ローカル関数、定数定義
# -----------------------------------------------
def get_target_model(session: Session, target_id: int) -> SampleModel:
    if (res := SampleCrud.get(session, target_id)) is None:
        message = F"不正ID:{target_id=}"
        ApiExceptionHelper.raise_http_404(message=message)
    return res


def get_valid_name(name: str) -> str:
    """入力文字列から有効な名前を抽出する"""
    try:
        return get_effective_string(s_in=name, min_len=1)
    except (ValueError, TypeError):
        message = F"不正な名前:{name=}"
        ApiExceptionHelper.raise_http_400(message=message)


# -----------------------------------------------
#  API End point/APIルータ定義
# -----------------------------------------------
router_sample = APIRouter(prefix="/sample", tags=['Sample'])
router_sample_admin = APIRouter(prefix="/sample", tags=['[Admin]Sample'])


@router_sample.post("/query", summary="データ検索", response_model=list[SampleModelResponse])
@router_sample_admin.post("/query", summary="データ検索", response_model=list[SampleModelResponse])
def query(
        session: Session = Depends(get_session),
        name: str | None = Query(default=None, description="検索値(名前文字列)"),
        operand: Operand = Query(default=Operand.LIKE, description="操作種別"),
):
    """### データ一覧の検索

    **Notes**
    - nameを指定した場合、operandで指定した条件(default:Like検索)で検索可能
    """
    logger.info(F"Start:{name=}\t{operand=}")
    query_list = [("name", operand, name)]
    filters = SampleCrud.set_filter(query_list=query_list)
    res = SampleCrud.query(session, filters=filters)
    logger.success(F"OK:{type(res)}\tlen={len(res)}")
    return res


@router_sample_admin.post("/register/{name}", summary="データ登録・更新", response_model=SampleModelResponse)
def register(
        session: Session = Depends(get_session),
        name: str = Path(default=..., description="指定名", min_length=1),
        params: SampleRegisterParams = Body(default=..., description="登録・更新データ")
):
    """### 指定名のデータ登録（新規登録、またはデータ更新)
    - 登録名がDBに未登録の場合: データを新規登録する
    - 登録名がDBに登録済の場合: データを更新登録する

    **Notes**
    - 特になし
    """
    logger.info(F"Start:{name=}\t{params=}")
    name = get_valid_name(name)
    kwargs = params.model_dump()
    res = SampleCrud.register(session, name=name, **kwargs)
    logger.success(F"OK:{type(res)}\t{res}")
    return res


@router_sample_admin.get("/by-name/{name}", summary="データ取得(名前検索)", response_model=SampleModelResponse | None)
def get_by_name(
        session: Session = Depends(get_session),
        name: str = Path(default=..., description="指定名", min_length=1),
):
    """### 指定名からデータ取得

    **Notes**
    - 指定名のデータが見つからない場合、None(null)を返す
    """
    logger.info(F"Start:{name=}")
    name = get_valid_name(name)
    res = SampleCrud.get_by_name(session, target_name=name)
    logger.success(F"OK:{type(res)}\t{res}")
    return res


@router_sample.get("/{target_id}", summary="データ取得", response_model=SampleModelResponse)
@router_sample_admin.get("/{target_id}", summary="データ取得", response_model=SampleModelResponse)
def get_by_id(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1, description="指定ID")
):
    """### 指定IDのデータ取得

    **Notes**
    - 指定データが見つからない場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}")
    res = get_target_model(session, target_id=target_id)
    logger.success(F"OK:{type(res)}\t{res}")
    return res


@router_sample_admin.put("/{target_id}", summary="データ更新", response_model=SampleModelResponse)
def update(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1, description="指定ID"),
        params: SampleUpdateParams = Body(default=..., description="更新内容"),
):
    """### 指定IDのデータ登録内容を更新（※名前属性を除く)

    **Notes**
    - 指定データが見つからない場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}\t{params=}")
    found_obj = get_target_model(session, target_id=target_id)
    kwargs = params.model_dump()
    res = SampleCrud.update(session, target_obj=found_obj, **kwargs)
    logger.success(F"OK:{type(res)}\t{res}")
    return res


@router_sample_admin.put("/rename/{target_id}/{name}", summary="データ名更新", response_model=SampleModelResponse)
def rename(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1, description="指定ID"),
        name: str = Path(default=..., description="更新名")
):
    """### 指定IDのデータ名を更新

    **Notes**
    - 指定データが見つからない場合、エラーを返す
    - 更新後の名前がDBに登録済の場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}\t{name=}")
    found_obj = get_target_model(session, target_id=target_id)
    name = get_valid_name(name)
    if SampleCrud.get_by_name(session, target_name=name, exclude_id=found_obj.id) is not None:
        message = F"名前の重複登録:{name=}"
        ApiExceptionHelper.raise_http_400(message=message)
    res = SampleCrud.update_name(session, target_obj=found_obj, name=name)
    logger.success(F"OK:{type(res)}\t{res}")
    return res


@router_sample_admin.delete("/{target_id}", summary="データ削除", response_model=SampleModelResponse)
def delete(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1, description="指定ID")
):
    """### 指定IDのデータ削除

    **Notes**
    - 指定データが見つからない場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}")
    res = get_target_model(session, target_id=target_id)
    SampleCrud.delete(session, target_obj=res)
    logger.success(F"OK:{type(res)}\t{res}")
    return res
