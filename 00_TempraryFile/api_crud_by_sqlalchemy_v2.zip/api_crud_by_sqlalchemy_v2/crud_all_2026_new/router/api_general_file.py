"""
概要: 汎用ファイルのアップロード・ダウンロード用APIルータ
更新: 2025/11/12
"""

# 標準ライブラリ
from __future__ import annotations
import os.path
import shutil
import mimetypes
import glob
# 拡張ライブラリ
from fastapi import APIRouter, File, UploadFile, Path
from fastapi.responses import FileResponse
from loguru import logger
# プライベートライブラリ
from router.helper_api_common import ApiExceptionHelper
from schema.schema_server import CommonResponse
from schema.schema_file import FileAttribute
from config import ServerConfig

# -----------------------------------------------
#  API End point/APIルータ定義
# -----------------------------------------------
UPLOAD_DIR = ServerConfig.upload_dir
router_general_file = APIRouter(prefix="/general-file", tags=["GeneralFile"])
router_general_file_admin = APIRouter(prefix="/general-file", tags=["[Admin]GeneralFile"])

@router_general_file.post("/query", summary="ファイル一覧", response_model=CommonResponse)
@router_general_file_admin.post("/query", summary="ファイル一覧", response_model=CommonResponse)
def query_file():
    """### [開発専用] 所定ディレクトリにアップロードしたファイル一覧の取得

    **Notes**
    - None
    """
    logger.info(F"Start")
    contents = glob.glob(F"{UPLOAD_DIR}/*")
    res = CommonResponse(status=True, attribute=UPLOAD_DIR, contents=contents)
    logger.success(F"OK:{res=}")
    return res


@router_general_file_admin.post("/upload", summary="ファイルアップロード", response_model=CommonResponse)
def upload(file: UploadFile = File(default=..., description="アップロード対象ファイル")):
    """### [開発専用] 任意ファイルをアップロードし、サーバの所定ディレクトリに保存する

    **Notes**
    - サーバーのファイルサイズ制約に触れた場合、エラーとなる
    """
    logger.info(F"Start:{file.filename=}\t{file.content_type=}")
    filename = file.filename
    out_file = os.path.join(UPLOAD_DIR, filename)
    # 入力データをサーバ内の所定ディレクトリにバイナリモードで格納する
    with open(out_file, "wb") as of:
        shutil.copyfileobj(file.file, of)
    attribute = FileAttribute(
        filename=filename,
        content_type=file.content_type,
        size=file.size,
    ).model_dump()
    contents = {
        "file_path": out_file,
    }
    res = CommonResponse(status=True, attribute=attribute, contents=contents)
    logger.success(F"OK:{res=}")
    return res


@router_general_file_admin.get("/contents/{filename}", summary="ファイル取得", response_model=CommonResponse)
def get_file_contents(filename: str = Path(default=..., description="ファイル名"), ):
    """### [開発専用] アップロード済のテキスト系ファイルのファイル内容を取得

    **Notes**
    - 指定ファイル名がみつからない場合、エラーとなる
    - 指定ファイルがテキストでない場合、エラーとなる
    - 指定ファイルのエンコードタイプが不正(UTF-8以外)の場合、エラーとなる
    """
    logger.info(F"Start:{filename=}")
    target_file = os.path.join(UPLOAD_DIR, filename)
    if not os.path.isfile(target_file):
        message = F"不正ファイル名:{filename=}"
        ApiExceptionHelper.raise_http_404(message=message)
    with open(target_file, 'r', encoding="utf-8") as file:
        contents = file.read()
    res = CommonResponse(status=True, attribute=filename, contents=contents)
    logger.success(F"OK:{res.attribute=}\t{type(res.contents)=}")
    return res


@router_general_file_admin.post("/download/{filename}", summary="ファイルダウンロード")
def download_file(filename: str = Path(default=..., description="ファイル名"), ):
    """### [開発専用] サーバへアップロードしたファイルのダウンロード

    **Notes**
    - 指定ファイル名が存在しない場合、エラーとなる
    - ファイル拡張子と中身があっていない場合、適切なMIMEタイプは返されない
    """
    logger.info(F"Start:{filename=}")
    target_file = os.path.join(UPLOAD_DIR, filename)
    if not os.path.isfile(target_file):
        message = F"指定ファイル名の不正:{filename=}"
        ApiExceptionHelper.raise_http_404(message=message)
    # ファイル名や拡張子に対応するMIMEタイプを推測し、設定する
    mime_type, encoding = mimetypes.guess_type(target_file)
    logger.trace(F"mimetypes.guess_type():{mime_type=}\t{encoding=}")
    # .csvファイルの拡張子でmimeタイプが意図通り判定されていない場合、MIMEタイプを手動設定する
    if ".csv" in filename.lower() and "csv" not in mime_type:
        mime_type = 'text/csv'
    logger.success(F"OK:{filename=}\t{mime_type=}")
    return FileResponse(path=target_file, filename=filename, media_type=mime_type)
