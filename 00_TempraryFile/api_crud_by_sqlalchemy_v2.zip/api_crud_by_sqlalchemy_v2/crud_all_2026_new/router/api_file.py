"""
概要: File model APIルータ
更新: 2025/11/14
"""

# 標準ライブラリ
from __future__ import annotations

import os
import shutil
# 拡張ライブラリ
from fastapi import Depends, APIRouter, Query, UploadFile, File, Path
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from loguru import logger
# プライベートライブラリ
from db_crud.database import get_session
from db_crud.crud_file import FileModel, FileCrud
from db_crud.crud_abstract import Operand
from common.library import get_effective_string
from schema.schema_file import (FileModelResponse, FileModelResponseFull, FileModelRegister, FileDirectoryContents)
from router.helper_api_common import ApiExceptionHelper
from router.helper_file import HelperFile, HelperFileRegister


# ------------------------------------------------------------
#  ローカル関数、定数定義
# ------------------------------------------------------------
def get_target_model(db: Session, target_id: int) -> FileModel:
    """指定IDのファイル取得。ファイルが見つからない場合、エクセプションとなる"""
    if (found_obj := FileCrud.get(db, target_id=target_id)) is None:
        message = F"不正ID:{target_id=}"
        ApiExceptionHelper.raise_http_404(message=message)
    return found_obj


def get_valid_name(name: str) -> str:
    """入力文字列から有効な名前を抽出する"""
    try:
        return get_effective_string(s_in=name, min_len=1)
    except (ValueError, TypeError):
        message = F"不正な名前:{name=}"
        ApiExceptionHelper.raise_http_400(message=message)


# -----------------------------------------------
#  API End point/APIルータ定義
# -----------------------------------------------
router_file = APIRouter(prefix="/file", tags=['File'])
router_file_admin = APIRouter(prefix="/file", tags=['[Admin]File'])


@router_file.post("/query", summary="ファイル一覧", response_model=list[FileModelResponse])
@router_file_admin.post("/query", summary="ファイル一覧", response_model=list[FileModelResponse])
def query(
        session: Session = Depends(get_session),
        name: str | None = Query(default=None, description="検索値(名前文字列)"),
        operand: Operand = Query(default=Operand.LIKE, description="操作種別"),
):
    """### ファイル一覧の検索

    **Notes**
    - nameを指定した場合、operandの指定条件(default:Like検索)で絞り込み検索可能
    - contents_typeを指定した場合、Like検索で絞り込み検索可能
    """
    logger.info(F"Start:{name=}\t{operand=}")
    query_list = [("name", operand, name)]
    filters = FileCrud.set_filter(query_list=query_list)
    res = FileCrud.query(session, filters=filters)
    logger.success(F"OK:{type(res)}\tlen={len(res)}")
    return res


@router_file_admin.post("/query/directory", summary="ディレクトリ内のファイル一覧",
                        response_model=FileDirectoryContents)
def query_directory():
    """### 所定ディレクトリにアップロードしたファイル一覧の取得

    **Notes**
    - None
    """
    logger.info(F"Start")
    res = HelperFileRegister.get_upload_directory_contents()
    logger.success(F"OK:{res=}")
    return res


@router_file_admin.post("/upload/dir_and_db", summary="ファイルアップロード", response_model=FileModelResponse)
def upload_dir_and_db(
        session: Session = Depends(get_session),
        file: UploadFile = File(default=..., description="登録ファイル"),
):
    """### ファイル登録(所定ディレクトリにファイルを保存し、併せてDBにもファイル内容を登録する)
    - 登録ファイル名がDBに未登録時：ファイルの新規登録
    - 登録ファイル名がDBに登録時：ファイルの更新登録

    **Notes**
    - TBD
    """
    logger.info(F"Start:{file.filename=}\t{file.content_type=}\tfile_body={type(file.file)}")
    helper = HelperFileRegister(file=file)
    out_file_path = helper.set_upload_file_path()
    try:
        # アップロードファイルを所定ディレクトリにコピーする
        with open(out_file_path, "wb") as of:
            shutil.copyfileobj(file.file, of)
        # アップロードファイルを所定ディレクトリにコピーする

        with open(out_file_path, "rb") as f:
            file_body = f.read()
    except Exception as e:
        message = F"ファイルエラー:{type(e)}\t{e.args=}"
        ApiExceptionHelper.raise_http_500(message=message)
    # ファイルをDBに登録する
    attribute = helper.get_file_attribute()
    kwargs = FileModelRegister(
        file_body=file_body,
        type=file.content_type,
        attribute=attribute,
    ).model_dump()
    res = FileCrud.register(session, name=file.filename, **kwargs)
    logger.success(F"End:ID={res.id}\t{res.name=}\t{res.attribute=}")
    return res


@router_file_admin.post("/upload", summary="ファイルアップロード", response_model=FileModelResponse)
def upload(
        session: Session = Depends(get_session),
        file: UploadFile = File(default=..., description="登録ファイル"),
):
    """### ファイル登録(DBにファイル内容を登録)
    - 登録ファイル名がDBに未登録時：ファイルの新規登録
    - 登録ファイル名がDBに登録時：ファイルの更新登録

    **Notes**
    - TBD
    """
    logger.info(F"Start:{file.filename=}\t{file.content_type=}\tfile_body={type(file.file)}")
    helper = HelperFileRegister(file=file)
    try:
        # アップロードファイルを直接バイナリモードで読み込む
        file_body = file.file.read()
    except Exception as e:
        message = F"ファイルエラー:{type(e)}\t{e.args=}"
        ApiExceptionHelper.raise_http_500(message=message)
    attribute = helper.get_file_attribute()
    # noinspection PyUnboundLocalVariable
    kwargs = FileModelRegister(
        file_body=file_body,
        type=file.content_type,
        attribute=attribute,
    ).model_dump()
    res = FileCrud.register(session, name=file.filename, **kwargs)
    logger.success(F"End:ID={res.id}\t{res.name=}\t{res.attribute=}")
    return res


@router_file_admin.post("/download/{target_id}", summary="ファイルダウンロード")
def download(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1, description="対象ID"),
):
    """### 指定IDのデータ内容をファイルとしてダウンロードする

    **Notes**
    - 指定ファイルが見つからない場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}")
    target_model = get_target_model(session, target_id=target_id)
    helper = HelperFile(file_model=target_model)
    file_path = helper.get_download_file_path()
    res = {
        "path": file_path,
        "filename": target_model.name,
        "media_type": target_model.type,
    }
    logger.success(F"OK:{type(res)}\t{res=}")
    return FileResponse(**res)


@router_file_admin.get("/by-name/{name}", summary="ファイル取得(名前検索)", response_model=FileModelResponseFull | None)
def get_by_name(
        session: Session = Depends(get_session),
        name: str = Path(default=..., description="指定名")
):
    """### 指定名のファイル取得

    **Notes**
    - 指定ファイル名が見つからない場合、None(null)を返す
    """
    logger.info(F"Start:{name=}")
    name = get_valid_name(name)
    res = FileCrud.get_by_name(session, target_name=name)
    if res is not None:
        logger.success(F"End:ID={res.id}\t{res.name=}\t{res.attribute=}")
    else:
        logger.success(F"{res=}")
    return res


@router_file.get("/{target_id}", summary="ファイル取得", response_model=FileModelResponseFull)
@router_file_admin.get("/{target_id}", summary="ファイル取得", response_model=FileModelResponseFull)
def get(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1, description="対象ID"),
):
    """### 指定IDのファイル取得

    **Notes**
    - 指定ファイルが見つからない場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}")
    res = get_target_model(session, target_id)
    logger.success(F"End:ID={res.id}\t{res.name=}\t{res.attribute=}")
    return res


@router_file_admin.get("/contents/{target_id}/as-text", summary="ファイル内容取得(テキスト)")
def get_as_text(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1, description="対象ID"),
):
    """### 指定IDのファイル内容をテキスト形式で取得

    **Notes**
    - 指定ファイルが見つからない場合、エラーを返す
    - ファイルがテキスト変換できない場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}")
    target_model = get_target_model(session, target_id=target_id)
    helper = HelperFile(file_model=target_model)
    res = helper.file_body2text()
    logger.success(F"OK:{type(res)}\t{len(res)=}")
    return res


@router_file_admin.get("/contents/{target_id}/as-list", summary="ファイル内容取得(リスト)")
def get_as_list(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1, description="対象ID"),
        max_lines: int = Query(default=5, ge=0, description="先頭からn行取得"),
):
    """### 指定IDのファイル登録内容をList形式で取得

    **Notes**
    - 指定ファイルが見つからない場合、エラーを返す
    - ファイルがテキスト変換できない場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}")
    target_model = get_target_model(session, target_id=target_id)
    helper = HelperFile(file_model=target_model)
    res = helper.file_body2list()
    if 0 < max_lines <= len(res):
        res = res[0:max_lines]
    logger.success(F"OK:{type(res)}\t{len(res)=}")
    return res


@router_file_admin.get("/{target_id}/as-json", summary="ファイル内容取得(JSON形式)")
def get_as_json(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1, description="対象ID"),
):
    """### 指定IDのファイル登録内容をJSONデータに変換して取得

    **Notes**
    - 指定ファイルが見つからない場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}")
    target_model = get_target_model(session, target_id=target_id)
    helper = HelperFile(file_model=target_model)
    res = helper.file_body2json()
    logger.success(F"OK:{type(res)}")
    return res


@router_file_admin.put("/rename/{target_id}/{name}", summary="データ名更新", response_model=FileModelResponse)
def rename(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1, description="対象ID"),
        name: str = Path(default=..., description="更新後のファイル名")
):
    """### 指定IDのデータ名を更新

    **Notes**
    - 指定データが見つからない場合、エラーを返す
    - 更新後の名前がDBに登録済の場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}\t{name=}")
    found_obj = get_target_model(session, target_id=target_id)
    name = get_valid_name(name)
    if FileCrud.get_by_name(session, target_name=name, exclude_id=found_obj.id) is not None:
        message = F"名前の重複登録:{name=}"
        ApiExceptionHelper.raise_http_400(message=message)
    res = FileCrud.update_name(session, target_obj=found_obj, name=name)
    logger.success(F"End:ID={res.id}\t{res.name=}\t{res.attribute=}")
    return res


@router_file_admin.delete("/{target_id}", summary="ファイル削除", response_model=FileModelResponse)
def delete(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1, description="対象ID"),
):
    """### 指定IDのファイル削除

    **Notes**
    - 指定ファイルが見つからない場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}")
    found_obj = get_target_model(session, target_id)
    out_file = found_obj.attribute.get("file_path")
    FileCrud.delete(session, target_obj=found_obj)
    # DB登録に伴い、所定ディレクトリに登録されているファイルも削除する
    if out_file is not None and os.path.isfile(out_file):
        logger.trace(F"ファイル削除:{out_file=}")
        os.remove(out_file)
    logger.success(F"End:{type(found_obj)}\t{found_obj}")
    return found_obj
