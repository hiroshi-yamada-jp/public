"""
概要: API helper ライブラリ
更新: 2025/06/16
"""

# 標準ライブラリ
from __future__ import annotations
# 拡張ライブラリ
from fastapi import HTTPException, status
from loguru import logger


# ------------------------------------------------------------
#  API ヘルパー関数
# ------------------------------------------------------------
class ApiExceptionHelper:
    """ API処理で発生する、共通例外処理のヘルパー"""

    @staticmethod
    def raise_http_400(message: str) -> None:
        """HTTP_400_BAD_REQUESTエクセプションの通知"""
        logger.error(F"HTTP_400_BAD_REQUEST:{message}")
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=message)

    @staticmethod
    def raise_http_404(message: str) -> None:
        """HTTP_404_NOT_FOUNDエクセプションの通知"""
        logger.error(F"HTTP_404_NOT_FOUND:{message}")
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=message)

    @staticmethod
    def raise_http_500(message: str) -> None:
        """HTTP_500_INTERNAL_SERVER_ERRORエクセプションの通知"""
        logger.error(F"HTTP_500_INTERNAL_SERVER_ERROR:{message}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=message)
