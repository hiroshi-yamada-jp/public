"""
概要: Item モデル用APIルータ
更新: 2025/11/14
"""

# 標準ライブラリ
from __future__ import annotations
# 拡張ライブラリ
from fastapi import Depends, APIRouter, Path, Body, Query
from sqlalchemy.orm import Session
from loguru import logger
# プライベートライブラリ
from db_crud.database import get_session
from db_crud.crud_abstract import Operand
from db_crud.crud_item import ItemModel, ItemCrud
from schema.schema_item import (ItemModelResponse, ItemRegisterParams, ItemUpdateParams)
from router.helper_api_common import ApiExceptionHelper
from common.library import get_effective_string


# ------------------------------------------------------------
#  API ヘルパー関数
# ------------------------------------------------------------
def get_target_model(session: Session, target_id: int) -> ItemModel:
    """指定IDのデータ取得。指定IDのデータが見つからない場合、エクセプションを発生"""
    if (res := ItemCrud.get(session, target_id)) is None:
        message = F"不正ID:{target_id=}"
        ApiExceptionHelper.raise_http_404(message=message)
    return res


def get_valid_name(name: str) -> str:
    """入力文字列から有効な名前を抽出する"""
    try:
        return get_effective_string(s_in=name, min_len=1)
    except (ValueError, TypeError):
        message = F"不正な名前:{name=}"
        ApiExceptionHelper.raise_http_400(message=message)


# -----------------------------------------------
#  API End point/APIルータ定義
# ポイント: APIRouterの定義によりモデル単位等の共通要素（パス名・タグ名等)定義が可能
# -----------------------------------------------
router_item = APIRouter(prefix="/item", tags=['Item'])
router_item_admin = APIRouter(prefix="/item", tags=['[Admin]Item'])


@router_item.post("/query", summary="データ検索", response_model=list[ItemModelResponse])
@router_item_admin.post("/query", summary="データ検索", response_model=list[ItemModelResponse])
def query(
        session: Session = Depends(get_session),
        name: str | None = Query(default=None, description="検索値(名前文字列)"),
        operand: Operand = Query(default=Operand.LIKE, description="操作種別"),
):
    """### データ一覧の検索

    **Notes**
    - nameを指定した場合、operandで指定した条件(default:Like検索)で検索可能
    """
    logger.info(F"Start:{name=}\t{operand=}")
    query_list = [("name", operand, name)]
    filters = ItemCrud.set_filter(query_list=query_list)
    res = ItemCrud.query(session, filters=filters)
    logger.success(F"OK:{type(res)}\tlen={len(res)}")
    return res


@router_item_admin.post("/register/{name}", summary="登録・更新", response_model=ItemModelResponse)
def register(
        session: Session = Depends(get_session),
        name: str = Path(default=..., description="指定名", min_length=1),
        params: ItemRegisterParams = Body(default=..., description="登録・更新データ"),
):
    """### 指定名のデータ登録（新規登録、または更新登録)
    - 登録名がDBに未登録の場合: データを新規登録する
    - 登録名がDBに登録済の場合: データを更新登録する

    **Notes**
    - 特になし
    """
    logger.info(F"Start:{name=}\t{params=}")
    valid_name = get_valid_name(name)
    kwargs = params.model_dump()
    res = ItemCrud.register(session, name=valid_name, **kwargs)
    logger.success(F"OK:{type(res)}\t{res}")
    return res


@router_item_admin.get("/by-name/{name}", summary="データ取得(名前検索)", response_model=ItemModelResponse | None)
def get_by_name(
        session: Session = Depends(get_session),
        name: str = Path(default=..., description="指定名", min_length=1)
):
    """### 指定名のデータ取得

    **Notes**
    - 指定名のデータが見つからない場合、None(null)を返す
    """
    logger.info(F"Start:{name=}")
    valid_name = get_valid_name(name)
    res = ItemCrud.get_by_name(session, target_name=valid_name)
    logger.success(F"OK:{type(res)}\t{res}")
    return res


@router_item.get("/{target_id}", summary="データ取得", response_model=ItemModelResponse)
@router_item_admin.get("/{target_id}", summary="データ取得", response_model=ItemModelResponse)
def get(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1, description="指定ID"),
):
    """### 指定IDのデータ取得

    **Notes**
    - 指定データが見つからない場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}")
    res = get_target_model(session, target_id)
    logger.success(F"OK:{type(res)}\t{res}")
    return res


@router_item_admin.put("/{target_id}", summary="データ更新", response_model=ItemModelResponse)
def update(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1, description="指定ID"),
        params: ItemUpdateParams = Body(default=..., description="更新内容"),
):
    """### 指定IDのデータ登録内容を更新（※名前属性を除く)

    **Notes**
    - 指定データが見つからない場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}\t{params=}")
    found_obj = get_target_model(session, target_id)
    kwargs = params.model_dump()
    res = ItemCrud.update(session, target_obj=found_obj, **kwargs)
    logger.success(F"OK:{type(res)}\t{res}")
    return res


@router_item_admin.put("/rename/{target_id}/{name}", summary="データ名更新", response_model=ItemModelResponse)
def rename(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1, description="指定ID"),
        name: str = Path(default=..., description="指定名", min_length=1),
):
    """### 指定IDのデータ名を更新

    **Notes**
    - 指定データが見つからない場合、エラーを返す
    - 更新後のデータ名がDBに登録済の場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}\t{name=}")
    found_obj = get_target_model(session, target_id=target_id)
    valid_name = get_valid_name(name)
    if ItemCrud.get_by_name(session, target_name=valid_name, exclude_id=found_obj.id) is not None:
        message = F"重複名の登録:{name=}"
        ApiExceptionHelper.raise_http_400(message=message)
    res = ItemCrud.update_name(session, target_obj=found_obj, name=valid_name)
    logger.success(F"OK:{type(res)}\t{res}")
    return res


@router_item_admin.delete("/{target_id}", summary="データ削除", response_model=ItemModelResponse)
def delete(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1, description="指定ID"),
):
    """### 指定IDのデータ削除

    **Notes**
    - 指定データが見つからない場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}")
    found_obj = get_target_model(session, target_id)
    ItemCrud.delete(session, target_obj=found_obj)
    logger.success(F"OK:{type(found_obj)}\t{found_obj}")
    return found_obj
