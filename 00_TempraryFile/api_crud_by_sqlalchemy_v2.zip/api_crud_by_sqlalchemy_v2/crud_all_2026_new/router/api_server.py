"""
概要: システム汎用APIルータ
更新: 2025/10/31
"""

# 標準ライブラリ
from __future__ import annotations
import platform
# 拡張ライブラリ
from fastapi import APIRouter, Request, Path
from loguru import logger
# プライベートライブラリ
from db_crud.database import Database
from schema.schema_server import CommonResponse, ServerInfoMenu, DatabaseMenu
from router.helper_api_common import ApiExceptionHelper
from config import ServerConfig, DBConfig

# ------------------------------------------
#  Admin用のAPI End point/APIルータ定義
# ------------------------------------------
router_server_admin = APIRouter(prefix="/server", tags=['[Admin]Server'])

@router_server_admin.get("/info/{function}", summary="サーバ情報表示", response_model=CommonResponse)
def get_server_info(req: Request, function: ServerInfoMenu = Path(default=..., description="機能名"), ):
    """### サーバ情報の表示

    **function**
    - Platform : Platform情報の表示
    - URL : URL情報の表示
    - Config : Config情報の表示

    **Note**:
    - None
    """
    logger.info(F'Start:{function=}')
    res = CommonResponse(status=True, attribute=function)
    if function == ServerInfoMenu.F_PF:
        res.contents = {
            "platform": platform.platform(),
            "node": platform.node(),
            "machine": platform.machine(),
            "python_version": platform.python_version(),
        }
    elif function == ServerInfoMenu.F_URL:
        res.contents = {
            "method": req.method,
            # ポイント：文字列以外の属性は文字列化しないとエラーとなる
            "base_url": str(req.base_url),
            "url": str(req.url),
            "headers": str(req.headers),
            "cookies": str(req.cookies),
            "client": str(req.client),
        }
    elif function == ServerInfoMenu.F_CONFIG:
        res.contents = {
            "server": ServerConfig.show_config(),
            "database": DBConfig.show_config(),
        }
    else:
        message = F"不正ファンクション:{function=}"
        ApiExceptionHelper.raise_http_400(message=message)
    logger.success(F"End:{res=}")
    return res


@router_server_admin.get("/db/{function}", summary="DB情報表示", response_model=CommonResponse)
def get_db_info(function: DatabaseMenu = Path(default=..., description="機能名")):
    """### DB情報の表示

    **function**
    - Database: DBステータスの表示
    - Table: DBテーブルの表示

    **Note**:
    - 特になし
    """
    logger.info(F'Start:{function=}')
    res = CommonResponse(status=True, attribute=function)
    if function == DatabaseMenu.DB_STATUS:
        res.contents = Database.get_info()
    elif function == DatabaseMenu.DB_TABLE:
        res.contents = Database.get_all_table_list()
    else:
        message = F"不正ファンクション:{function=}"
        ApiExceptionHelper.raise_http_400(message=message)
    logger.success(F"End:{res=}")
    return res


@router_server_admin.post("/db/init_db", summary="[DEV]DB初期化", response_model=CommonResponse)
def init_db_table():
    """### [開発専用] データベーステーブル初期化

    **Note**:
    - テスト目的以外の利用は、一切禁止
    - Database初期化後はサーバーを再起動すること
    """
    logger.warning(F'Start')
    function = "Initialize_DB"
    res = CommonResponse(status=True, attribute=function)
    Database.initialize_all_table()
    res.contents = Database.get_info()
    logger.success(F"End:{res=}")
    return res
