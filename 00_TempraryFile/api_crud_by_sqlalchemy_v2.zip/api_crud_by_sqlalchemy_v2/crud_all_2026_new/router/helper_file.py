"""
概要: File model Helper
更新: 2026/06/19
"""

# 標準ライブラリ
from __future__ import annotations
from typing import Any
import os
import glob
import json
import io
# 拡張ライブラリ
import polars as pl
from fastapi import UploadFile
# プライベートライブラリ
from db_crud.crud_file import FileModel
from router.helper_api_common import ApiExceptionHelper
from config import ServerConfig
from schema.schema_file import FileAttribute, FileDirectoryContents

ENCODING = "utf-8"  # "utf-8-sig" | "cp932"


# -----------------------------------------------
#  ヘルパー関数定義
# -----------------------------------------------
class HelperFile:
    TEMP_DIR = ServerConfig.temp_dir

    """ファイルモデル用ヘルパー"""

    def __init__(self, file_model: FileModel):
        """コンストラクタ"""
        self.__file_model = file_model
        self.__file_body = file_model.file_body
        self.temp_dir = ServerConfig.temp_dir

    def file_body2text(self) -> str:
        """ファイル内容(バイナリ)をテキスト形式で取得する。変換できない場合、エクセプションとなる"""
        try:
            return self.__file_body.decode(encoding=ENCODING)
        except UnicodeDecodeError as e:
            message = F"テキスト変換エラー:{type(e)}\t{e.args=}"
            ApiExceptionHelper.raise_http_400(message=message)

    def file_body2list(self) -> list:
        """ファイル内容(バイナリ)をList形式で取得する。変換できない場合、エクセプションとなる"""
        try:
            text_content = self.file_body2text()
            return text_content.splitlines()
        except Exception as e:
            message = F"リスト変換エラー:{type(e)}\t{e.args=}"
            ApiExceptionHelper.raise_http_400(message=message)

    def file_body2json(self) -> Any:
        """ファイル内容(バイナリ)をJSONデータ(Pythonオブジェクト)で取得する。変換できない場合、エクセプションとなる"""
        try:
            text_content = self.file_body2text()
            return json.loads(text_content)
        except (UnicodeDecodeError, json.JSONDecodeError) as e:
            message = F"JSON変換エラー:{type(e)}\t{e.args=}"
            ApiExceptionHelper.raise_http_400(message=message)

    def file_body2df(self) -> pl.DataFrame:
        """ファイル内容(バイナリ)をデータフレーム形式に変換する。変換できない場合、エクセプションとなる"""
        try:
            text_content = self.file_body2text()
            csv_data = io.StringIO(text_content)
            return pl.read_csv(source=csv_data)
        except Exception as e:
            message = F"データ変換エラー:{type(e)}\t{e.args=}"
            ApiExceptionHelper.raise_http_400(message=message)

    def get_download_file_path(self) -> str:
        """ファイル内容(バイナリ)をファイルに出力し、生成したファイルパスを返す"""
        out_file_path = os.path.join(self.TEMP_DIR, self.__file_model.name)
        try:
            with open(out_file_path, "wb") as of:
                of.write(self.__file_body)
        except Exception as e:
            message = F"ファイルエラー:{type(e)}\t{e.args=}"
            ApiExceptionHelper.raise_http_500(message=message)
        return out_file_path


class HelperFileRegister:
    """ファイル登録用ヘルパー"""
    UPLOAD_DIR = ServerConfig.upload_dir

    def __init__(self, file: UploadFile) -> None:
        """コンストラクタ"""
        self.__file = file
        self.__upload_file_path = None

    def set_upload_file_path(self) -> str:
        """アップロードファイルの出力ファイルパスを設定する"""
        self.__upload_file_path = os.path.join(self.UPLOAD_DIR, self.__file.filename)
        return self.__upload_file_path

    @classmethod
    def get_upload_directory_contents(cls) -> FileDirectoryContents:
        upload_dir = cls.UPLOAD_DIR
        file_path_list = glob.glob(F"{upload_dir}/*")
        # ファイルパス付のファイル名をファイル名一覧に変更
        files = [os.path.basename(filename) for filename in file_path_list]
        res = FileDirectoryContents(
            directory=upload_dir,
            file_count=len(file_path_list),
            files=files,
        )
        return res

    def get_file_attribute(self) -> FileAttribute:
        res = FileAttribute(
            filename=self.__file.filename,
            content_type=self.__file.content_type,
            size=self.__file.size,
            file_path=self.__upload_file_path,
        )
        return res
