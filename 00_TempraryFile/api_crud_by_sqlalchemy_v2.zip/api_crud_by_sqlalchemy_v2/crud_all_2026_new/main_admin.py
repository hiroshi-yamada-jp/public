"""
概要: Admin Mode APIサブアプリ
更新: 2025/11/07
注意:
- DB初期設定等の初期設定は、main.pyで行う設計のため、単独起動時は初回起動前にmain.pyで起動しておくこと
"""

# 標準ライブラリ
import os
# 拡張ライブラリ
from fastapi import FastAPI
# プライベートライブラリ
from config import ServerConfig
# サブルータ
from router.api_server import router_server_admin
from router.api_sample import router_sample_admin
from router.api_item import router_item_admin
from router.api_file import router_file_admin
from router.api_general_file import router_general_file_admin

# ----------------------------------
#  API サーバ定義
# ----------------------------------
title = "[Admin] API server for admin mode"
version = ServerConfig.version
description = """
### 説明
- 機能1
"""
app = FastAPI(title=title, description=description, version=version)

# -------------------------------------------------
# Admin API Router
# -------------------------------------------------
admin_api_enable = True
app.include_router(router_server_admin, include_in_schema=admin_api_enable)
app.include_router(router_sample_admin, include_in_schema=True)
app.include_router(router_item_admin, include_in_schema=True)
app.include_router(router_file_admin, include_in_schema=admin_api_enable)
app.include_router(router_general_file_admin, include_in_schema=admin_api_enable)

# -------------------------------------------------
#  コマンドラインからの起動
# -------------------------------------------------
if __name__ == '__main__':
    import uvicorn

    # 実行ファイル名から拡張子を除いたファイル名を取得し、appの起動名を生成する
    name = os.path.splitext(os.path.basename(__file__))[0]
    app_name = F"{name}:app"
    uvicorn.run(app=app_name, host="localhost", port=8010, reload=True)
