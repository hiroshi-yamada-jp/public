"""
概要: 抽象モデルのモデル定義とCRUDライブラリ
更新: 2025/11/14
"""

# 標準ライブラリ
from __future__ import annotations
import datetime as dt
from typing import Sequence, Any, Union
from abc import ABC
from enum import Enum
# 拡張ライブラリ
from sqlalchemy.orm import Session, Mapped, mapped_column
from sqlalchemy import asc, select, String, DateTime, Integer, and_, func
# プライベートライブラリ
from db_crud.database import Base
from config import DBConfig

MAX_LEN = DBConfig.max_length

# 参考:mapped_column関数の主パラメータとデフォルト値
"""
パラメータ	    説明	                                    デフォルト値
primary_key	    主キーの設定	                                False(主キーにしない)
unique	        データの一意制約                              False(一意にしない)
nullable	    NULL値の許可	                                True(NULL許可)
index	        インデックスを作成するかどうか	                False(インデックスを作成しない)
default	        デフォルトの設定値                            なし
autoincrement	自動インクリメントを有効にするかどうか	        None (データ型により自動設定)
onupdate	    更新時の値（例：func.now()）	                なし
comment	        カラムに対するコメント	                        なし
repr            repr()関数で属性表示に表示抑制する              True（表示する)
"""


class Operand(Enum):
    """DB Queryに対する許容オペレーション"""
    LIKE = "lIKE"  # 文字列の部分一致
    NOT_LIKE = "NOT_LIKE"  # 文字列の部分一致の否定
    EQ = "EQ"  # 一致（数値、文字列)
    NE = "NE"  # 文字列の不一致（数値、文字列)
    GE = "GE"  # 指定値以上（数値、日時)
    LE = "LE"  # 指定値以下（数値、日時)


class AbstractModel(Base):
    """モデル定義 ※ 基底となる抽象クラス"""
    __abstract__ = True  # 実テーブルを作成しない抽象基底クラス
    id: Mapped[int] = mapped_column(Integer, primary_key=True, unique=True, autoincrement=True, comment="ID")
    # name属性は、設計上重複禁止だが、実装方式の都合で、unique=Trueは設定せず、利用側で重複禁止を行う設計
    name: Mapped[str] = mapped_column(String(MAX_LEN), default="", index=True, nullable=False, comment="名前")
    # 自動作成の作成・更新日時データ(UTCでDBサーバ側の時刻を持つのが本来は正しいが、この実装では現地時間を使っている
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=dt.datetime.now,
                                                    comment="登録日時（自動設定)")
    updated_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=dt.datetime.now,
                                                    onupdate=dt.datetime.now, comment="更新日時（自動設定)")


class AbstractCrud(ABC):
    """モデル用CRUDライブラリ ※ 基底となる抽象クラス"""
    Model = AbstractModel  # モデル変数

    @classmethod
    def query(cls, db: Session, filters: list | None = None) -> Sequence[Any]:
        """DB内の全登録データから条件に一致するデータをID順にソートして抽出

        Args:
            db: DBセッション
            filters: 検索用Filter
        Returns:
            検索結果の一覧リスト (検索データがみつからない場合、空リストを返す)
        """
        if filters:
            stmt = select(cls.Model).filter(and_(*filters)).order_by(asc(cls.Model.id))
        else:
            stmt = select(cls.Model).order_by(asc(cls.Model.id))
        return db.execute(stmt).scalars().all()

    @classmethod
    def __set_filter(cls, *, filters: list, name: str, operand: Operand, value: str | int) -> None:
        """Filterリストに指定条件のDB検索を追加設定する

        Args:
            filters: 設定（追加)対象の検索リスト
            name: query対象のカラム名 (例:"name")
            operand : Query操作の種類 (例: Operand.LIKE)
            value:  条件値
        """
        # モデルからカラム名に一致する属性を取得する
        column = getattr(cls.Model, name)
        if operand == Operand.EQ:
            filters.append(column == value)
        elif operand == Operand.NE:
            filters.append(column != value)
        elif operand == Operand.LIKE:
            filters.append(column.like(f"%{str(value)}%"))
        elif operand == Operand.NOT_LIKE:
            # Likeの否定
            filters.append(~column.like(f"%{str(value)}%"))
        elif operand == Operand.GE:
            filters.append(column >= value)
        elif operand == Operand.LE:
            filters.append(column <= value)

    @classmethod
    def __set_fileter_between(cls, *, filters: list, name: str, v1: int | dt.datetime, v2: int | dt.datetime) -> None:
        """FilterリストにBetween条件のDB検索を追加設定する

        Args:
            filters: 設定（追加)対象の検索リスト
            name: query対象のカラム名 (例:"name")
            v1: 開始値、または開始日時
            v2: 終了日時
        """
        # モデルからカラム名に一致する属性を取得する
        column = getattr(cls.Model, name)
        filters.append(column.between(v1, v2))

    @classmethod
    def set_filter(cls, *, query_list: list[tuple[str, Operand, Union[str, int, dt.datetime, None]]]) -> list:
        """ DB検索用のFilter条件の設定(複数カラム名の指定操作)

            Args:
                query_list: 検索条件の下記タプル構造のリスト
                    - str: query対象のカラム名 (例:"name")
                    - Operand : Query操作の種類 (例: Operand.LIKE)
                    - any: 値 または "between" の場合は list or tuple(開始値, 終了値)
            Returns:
                検索用filter（SQLAlchemyの条件リスト）
            """
        filters = []
        # name指定と値が有効かつ、モデルに指定名の属性が存在すればFilterを設定する
        for name, operation, value in query_list:
            if isinstance(name, str) and value is not None:
                if hasattr(cls.Model, name):
                    cls.__set_filter(filters=filters, name=name, operand=operation, value=value)
        return filters

    @classmethod
    def get(cls, db: Session, target_id: int) -> Any | None:
        """指定IDのデータ取得

        Args:
            db: DBセッション
            target_id: 取得対象のID番号(Primary Key)
        Returns:
            Model:取得データ / None: データが見つからない
        """
        return db.get(cls.Model, target_id)

    @classmethod
    def get_by_name(cls, db: Session, target_name: str, *, exclude_id: int = -1) -> Any | None:
        """指定データ(by name)の取得。オプションとして検索対象から除外するidを指定可能
        Args:
            db: DBセッション
            target_name: 検索対象の名前
            exclude_id: 検索から除外するid / 0または負の値: 除外するidの指定が無効
        Returns:
            Model:検索対象データ / None: データが見つからない
        """
        name = target_name
        if exclude_id > 0:
            stmt = select(cls.Model).filter(cls.Model.name == name).filter(cls.Model.id != exclude_id)
        else:
            stmt = select(cls.Model).filter(cls.Model.name == name)
        return db.execute(stmt).scalars().one_or_none()

    @classmethod
    def register(cls, db: Session, name: str, **kwargs: dict) -> Any:
        """指定データの新規登録または、更新

        Args:
            db:  DBセッション
            name:  登録対象の名前
            kwargs: データ登録または更新内容。 設定例:  { "description": "XXXX" }
        Returns:
            Model:登録データ
        """
        if (target_obj := cls.get_by_name(db, target_name=name)) is None:
            target_obj = cls.Model(name=name)
            db.add(target_obj)
        # 入力された属性を使って、作成したデータの各属性を設定更新
        return cls.update(db, target_obj=target_obj, **kwargs)

    # registerを追加したので、作成のみ行う場合に利用する
    @classmethod
    def create(cls, db: Session, **kwargs: dict) -> Any:
        """指定データの新規登録

        Args:
            db:  DBセッション
            kwargs: データ登録内容。 設定例:  { "description": "XXXX" }
        Returns:
            Model:登録データ
        """
        new_obj = cls.Model()
        db.add(new_obj)
        # 入力された属性を使って、作成したデータの各属性を設定更新
        return cls.update(db, target_obj=new_obj, **kwargs)

    @staticmethod
    def update(db: Session, target_obj, **kwargs: dict[str, Any]) -> Any:
        """指定データの内容更新

        Args:
            db: DBセッション
            target_obj: 対象データ
            kwargs: 更新内容。更新しない属性値はNoneを設定。設定例:  {　"description":"XXX", "attribute" : None }
        Returns:
            Model:更新データ
        """
        # 更新属性が指定キーと一致し、かつ有効値の場合、その属性を指定値で更新する
        for up_key, up_val in kwargs.items():
            if up_val is not None and hasattr(target_obj, up_key):
                setattr(target_obj, up_key, up_val)
        # 更新データをDBへ登録し、リフレッシュする
        db.commit()
        db.refresh(target_obj)
        return target_obj

    @staticmethod
    def update_name(db: Session, target_obj, name: str) -> Any:
        """指定データの名前更新

        Args:
            db: DBセッション
            target_obj: 対象データ
            name: 更新後の名前
        Returns:
            Model:更新データ
        Notes:
            指定名の重複検査は、事前に利用側で行っておくこと
        """
        target_obj.name = name
        # 更新データをDBへ登録し、リフレッシュする
        db.commit()
        db.refresh(target_obj)
        return target_obj

    @staticmethod
    def delete(db: Session, target_obj) -> None:
        """指定データの削除

        Args:
            db: DBセッション
            target_obj: 対象データ
        Returns:
            None
        """
        db.delete(target_obj)
        db.commit()
