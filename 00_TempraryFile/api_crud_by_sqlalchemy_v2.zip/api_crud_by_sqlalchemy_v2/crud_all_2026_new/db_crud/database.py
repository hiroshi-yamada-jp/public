"""
概要: DB定義 (sqlalchemy 2.0スタイル)
更新: 2025/10/15
"""

from __future__ import annotations
# 標準ライブラリ
import os
# 拡張ライブラリ
from sqlalchemy import create_engine, inspect
from sqlalchemy.orm import sessionmaker, DeclarativeBase
# プライベートライブラリ
from config import DBConfig

# ---------------------------------------------
#  初期設定・ファンクション定義
# ---------------------------------------------
if DBConfig.db_mode == 0:
    # SQLite3のDBを利用
    db_engine = create_engine(DBConfig.db_uri, echo=DBConfig.echo_mode, connect_args={"check_same_thread": False})
else:
    # 本番用DB(postgresql)のエンジン設定
    # pool_pre_ping:プールのコネクション時にpingでActive状態を確認するので、接続切れエラーを回避可能
    db_engine = create_engine(DBConfig.db_uri, echo=DBConfig.echo_mode, pool_pre_ping=True)

SessionLocal = sessionmaker(bind=db_engine, autocommit=False, autoflush=False)


class Base(DeclarativeBase):
    pass


def get_session():
    """各APIリクエスト毎のDBセッション管理"""
    session = SessionLocal()
    try:
        yield session
    except Exception as e:
        # 例外発生時は、セッション内の処理をRollback()させる
        session.rollback()
        session.close()
        raise e
    finally:
        # 成功、エラー終了にかかわらず、セッション完了時はclose処理を行う
        session.close()


class Database:
    """SQLite3用データベースクラス:オブジェクト化しなくても利用可能なクラス定義"""

    @staticmethod
    def setup_db_table() -> None:
        """DB格納ディレクトリとDBテーブルの作成。作成済の場合は、何もしない"""
        if DBConfig.db_mode == 0:
            os.makedirs(DBConfig.db_path, exist_ok=True)
        Base.metadata.create_all(db_engine)

    @classmethod
    def initialize_all_table(cls) -> None:
        """データベース初期化: DB内のテーブルの初期化"""
        Base.metadata.drop_all(db_engine)
        cls.setup_db_table()

    @classmethod
    def get_all_table_list(cls) -> list:
        inspector = inspect(db_engine)
        return inspector.get_table_names()

    @classmethod
    def initialize_target_table(cls, model) -> None:
        """データベース初期化: DB内の指定モデル用のテーブル初期化

        Args:
            model: モデル名(NodeModel等)
        """
        Base.metadata.drop_all(
            db_engine,
            tables=[model.__table__],  # 削除したいテーブル名のリストを指定
            checkfirst=True
        )
        # 削除したテーブルの再作成
        cls.setup_db_table()

    @classmethod
    def get_info(cls) -> dict:
        """データベース設定情報の取得"""
        res = {
            "DBConfig.db_mode": DBConfig.db_mode,
            "db_engine": repr(db_engine),
            "db_engine.pool.status()": db_engine.pool.status(),
        }
        return res
