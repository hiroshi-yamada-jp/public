"""
概要: サンプルモデルのモデル定義とCRUDライブラリ
更新: 2025/11/04
"""

# 標準ライブラリ
from __future__ import annotations
# 拡張ライブラリ
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy import Text, JSON
# プライベートライブラリ
from db_crud.crud_abstract import AbstractModel, AbstractCrud


class SampleModel(AbstractModel):
    """モデル定義 ※ 抽象クラスの継承なので、追加更新属性の再定義が必要"""
    __tablename__ = 'sample_model'  # テーブル名は任意
    description: Mapped[str] = mapped_column(Text, default="", comment="説明")
    attribute: Mapped[dict] = mapped_column(JSON, default=dict, comment="属性")

    def __repr__(self):
        """データ内容の表示"""
        append_ab = F"id={self.id},name={repr(self.name)}"
        append = F"description={repr(self.description)},attribute={self.attribute}"
        append_dt = F"created_at={self.created_at},updated_at={self.updated_at}"
        return F"<SampleModel({append_ab},{append},{append_dt}>"


class SampleCrud(AbstractCrud):
    """モデル用CRUDライブラリ ※ 抽象クラスの継承なので、追加更新属性・メソッドの再定義が必要"""

    Model = SampleModel  # 利用モデルのクラス変数の再定義
