"""
概要: アイテムモデルのモデル定義とCRUDライブラリ
更新: 2025/11/04
"""
# 標準ライブラリ
from __future__ import annotations
# 拡張ライブラリ
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy import Boolean, JSON, Text, Integer
# プライベートライブラリ
from db_crud.crud_abstract import AbstractModel, AbstractCrud


class ItemModel(AbstractModel):
    """モデル定義 ※ 抽象クラスの継承なので、追加更新属性の再定義が必要"""
    __tablename__ = 'item_model'  # テーブル名は任意
    description: Mapped[str] = mapped_column(Text, default="", comment="説明")
    flag: Mapped[bool] = mapped_column(Boolean, default=False, comment="Boolデータ")
    number: Mapped[int] = mapped_column(Integer, default=0, comment="整数データ")
    attribute: Mapped[dict] = mapped_column(JSON, default=dict, comment="属性(dict構造)")
    array_data: Mapped[list] = mapped_column(JSON, default=list, comment="listデータ")

    def __repr__(self):
        """データ内容の表示"""
        append_ab = F"id={self.id},name={repr(self.name)}"
        append = F"description={repr(self.description)},flag={self.flag},number={self.number}"
        append2 = F"attribute={self.attribute},array_data={self.array_data}"
        append_dt = F"created_at={self.created_at},updated_at={self.updated_at}"
        return F"<SampleModel({append_ab},{append},{append2},{append_dt}>"


class ItemCrud(AbstractCrud):
    """Itemモデル用CRUD ※ 抽象クラスの継承なので、追加更新属性・メソッドの再定義が必要"""
    Model = ItemModel  # 利用モデルのクラス変数の再定義
