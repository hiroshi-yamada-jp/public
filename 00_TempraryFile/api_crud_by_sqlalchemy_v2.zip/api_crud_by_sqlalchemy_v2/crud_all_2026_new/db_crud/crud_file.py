"""
概要: FileModel & CRUD
更新: 2025/11/13
"""

# 標準ライブラリ
from __future__ import annotations
# 拡張ライブラリ
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy import JSON, String, LargeBinary
# プライベートライブラリ
from db_crud.crud_abstract import AbstractModel, AbstractCrud, MAX_LEN


class FileModel(AbstractModel):
    """モデル定義 ※ 抽象クラスの継承なので、追加または更新属性定義が必要"""
    __tablename__ = 'file_model'  # テーブル名は任意
    name: Mapped[str] = mapped_column(String(MAX_LEN), default=..., nullable=False, comment="ファイル名")
    type: Mapped[str] = mapped_column(String(MAX_LEN), default="", comment="ファイルタイプ")
    attribute: Mapped[dict] = mapped_column(JSON, default=dict, comment="ファイル属性")
    # ファイルの中身はバイナリで保存し、内容を取得時にテキストやJSONに変換する方法をとる
    file_body: Mapped[bytes] = mapped_column(LargeBinary, default=None, comment="ファイル内容（バイナリ)")

    def __repr__(self):
        """データ内容の表示"""
        append_ab = F"id={self.id},name={repr(self.name)},type={repr(self.type)}"
        append = F"attribute={self.attribute},file_body={self.file_body}"
        append_dt = F"created_at={self.created_at},updated_at={self.updated_at}"
        return F"<FileModel({append_ab},{append},{append_dt}>"


class FileCrud(AbstractCrud):
    """File Model CRUD処理 ※ 抽象クラスの継承なので、追加または更新属性定義が必要"""
    Model = FileModel
