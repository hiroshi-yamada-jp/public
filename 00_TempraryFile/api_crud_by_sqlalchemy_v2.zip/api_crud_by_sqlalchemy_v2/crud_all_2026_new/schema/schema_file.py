"""
概要: JsonFile Model API Schema
更新: 2025/11/13
"""

# 標準ライブラリ
from __future__ import annotations
from datetime import datetime
# 拡張ライブラリ
from pydantic import BaseModel, Field


# ----------------------------------------------------------------------
#  汎用属性定義
# ----------------------------------------------------------------------
class FileAttribute(BaseModel):
    filename: str = Field(default="", description="アップロード時のファイル名")
    content_type: str = Field(default="", description="アップロード時のコンテンツタイプ)")
    size: int = Field(default=0, description="アップロード時のファイルサイズ")
    file_path: str | None = Field(default=None, description="アップロード時の保存ファイルパス")


class FileModelRegister(BaseModel):
    """Fileモデル登録用構造定義"""
    type: str | None = Field(default=None, description="コンテンツタイプ)")
    attribute: FileAttribute | None = Field(default=None, description="ファイル属性")
    file_body: bytes | str | None = Field(default=None, description="ファイル内容")

class FileDirectoryContents(BaseModel):
    """所定ディレクトリ内のファイル一覧"""
    directory: str = Field(default=None, description="ディレクトリ名")
    file_count: int = Field(default=-1, description="ファイル数")
    files: list = Field(default_factory=list, description="ファイル名一覧")

# ----------------------------------------------------------------------
#  APIレスポンス定義
# ----------------------------------------------------------------------
class FileModelResponse(BaseModel):
    """API応答形式定義(基本形)"""
    id: int
    name: str
    type: str
    attribute: dict
    created_at: datetime
    updated_at: datetime


class FileModelResponseFull(FileModelResponse):
    """API応答形式定義 ※ FileResponseBaseを継承することで、追加分を指定する"""
    file_body: str | bytes


