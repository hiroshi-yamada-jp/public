"""
概要: Sampleモデルのスキーマ定義
更新: 2025/11/14
"""

# 標準ライブラリ
from __future__ import annotations
from datetime import datetime
# 拡張ライブラリ
from pydantic import BaseModel, Field, model_validator
# プライベートライブラリ
from config import DBConfig

# ------------------------------
#  APIパラメータ定義
# ------------------------------
MAX_LENGTH = DBConfig.max_length


class SampleRegisterParams(BaseModel):
    """登録APIのスキーマ定義:この説明もSwaggerUIに表示される
    """
    description: str = Field(default="", description="説明", max_length=MAX_LENGTH)
    attribute: dict = Field(default_factory=dict, description="属性")


class SampleUpdateParams(BaseModel):
    """Update  or Register APIパラメータのスキーマ定義"""
    description: str | None = Field(default=None, description="説明(省略時は元の値を保持)", max_length=MAX_LENGTH)
    attribute: dict | None = Field(default=None, description="属性(省略時は元の値を保持)")

    @model_validator(mode='after')
    def check_params(self):
        """パラメータの検査　※　modeがafterの場合、各値が単体検証済みインスタンスとして扱うことが可能
        Returns:
            self: 検査完了した全パラメータ値
        """
        if self.description is None and self.attribute is None:
            raise ValueError(F'更新データが未登録: {self}')
        return self


# ------------------------------
#  APIレスポンス定義
# ------------------------------
class SampleModelResponse(BaseModel):
    """API応答形式定義(Full形式)"""
    id: int
    name: str
    attribute: dict
    description: str
    created_at: datetime
    updated_at: datetime
