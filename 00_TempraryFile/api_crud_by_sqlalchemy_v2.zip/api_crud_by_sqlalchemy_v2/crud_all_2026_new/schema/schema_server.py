"""
概要: 汎用APIのスキーマ定義
更新: OK 2025/10/16
"""

from __future__ import annotations
# 標準ライブラリ
from typing import Any
from enum import Enum
# 拡張ライブラリ
from pydantic import BaseModel, Field


# ------------------------------
# APIパラメータ定義
# ------------------------------
class ServerInfoMenu(str, Enum):
    """サーバ情報表示機能の定義"""
    F_PF = "Platform"
    F_URL = "URL"
    F_CONFIG = "Config"


class DatabaseMenu(str, Enum):
    """データベース機能の定義"""
    DB_STATUS = "Database"
    DB_TABLE = "Table"


# ------------------------------
#  APIのレスポンス定義
# ------------------------------
class CommonResponse(BaseModel):
    """Common APIレスポンス定義"""
    status: bool = Field(default=False, description="True:OK/False:NG")
    attribute: Any = Field(default=None, description="任意タイプの属性")
    contents: Any = Field(default=None, description="実行結果")
