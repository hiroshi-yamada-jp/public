"""
概要: Itemモデルのスキーマ定義
更新: 2025/11/13
"""

# 標準ライブラリ
from __future__ import annotations
from datetime import datetime
# 拡張ライブラリ
from pydantic import BaseModel, Field, model_validator


# ------------------------------
#  APIパラメータ定義
# ------------------------------
class ItemRegisterParams(BaseModel):
    """登録APIのスキーマ定義:この説明もSwaggerUIに表示される
    """
    description: str = Field(default="", description="TEXT型(指定省略時はデフォルト値を設定)")
    flag: bool = Field(default=False, description="Bool型(指定省略時はデフォルト値を設定)")
    number: int = Field(default=0, ge=0, description="0以上の整数(指定省略時はデフォルト値を設定)", )
    # dict/list等の場合は、default_factoryパラメータで初期値を設定しないと警告が出る
    attribute: dict = Field(default_factory=dict, description="0以上の整数(指定省略時はデフォルト値を設定)")
    array_data: list[int] = Field(default_factory=list, description="整数リスト(指定省略時はデフォルト値を設定)")

    @model_validator(mode='after')
    def check_params(self):
        """パラメータの検査　※　modeがafterの場合、各値が単体検証済みインスタンスとして扱うことが可能
        Returns:
            self: 検査完了した全パラメータ値
        """
        if self.number is not None:
            if not (0 <= self.number <= 100):
                raise ValueError(F'不正な値: {self.number=}')
        return self


class ItemUpdateParams(BaseModel):
    """更新APIのスキーマ定義:この説明もSwaggerUIに表示される
    ポイント
    ・ 更新時は、デフォルト値にNoneを設定し、指定がない場合、更新させない仕様とする。ただし、SwaggerUI上は、値が表示されてしまう。
    """
    description: str | None = Field(default=None, description="TEXT型(指定省略時は元の値維持)")
    flag: bool | None = Field(default=None, description="Bool型(指定省略時は元の値維持)")
    number: int | None = Field(default=None, ge=0, description="0以上の整数(指定省略時は元の値維持)")
    attribute: dict | None = Field(default=None, description="辞書型データ(指定省略時は元の値維持)")
    array_data: list[int] | None = Field(default=None, description="整数リスト(指定省略時は元の値維持)")

    @model_validator(mode='after')
    def check_params(self):
        """パラメータの検査　※　modeがafterの場合、各値が単体検証済みインスタンスとして扱うことが可能
        Returns:
            self: 検査完了した全パラメータ値
        """
        if self.number is not None:
            if not (0 <= self.number <= 100):
                raise ValueError(F'不正な値: {self.number=}')
        return self


# ------------------------------
#  APIレスポンス定義
# ------------------------------
class ItemModelResponse(BaseModel):
    """API応答形式"""
    id: int
    name: str
    description: str
    flag: bool
    number: int
    array_data: list
    attribute: dict
    created_at: datetime
    updated_at: datetime
