"""
概要: Debug tool Library
更新: 2025/11/07
"""

# 標準ライブラリ
from __future__ import annotations
import inspect


def get_caller_function_name(level: int = 2) -> str:
    """本関数の呼び出し元の関数名を取得する、　Levelにより入れ子設定が可能

    Args:
        level: 呼び出しレベルの設定(1-3までの数)
        1: 本関数の呼び出し元の関数
        2: 本関数の呼び出し元の呼び出し元の関数
        3: 本関数の呼び出し元の呼び出し元の呼び出し元関数

    Returns:
        (str) 呼び出し元の関数名情報、存在しない場合は空白を返す
    """
    try:
        # 呼び出しレベルに応じた関数名を取得
        base = inspect.stack()[level]
        res = base.function  # ファンクション名
        # res = base.lineno   # 行数の場合
    except IndexError:
        # 指定レベルの呼び出し元が存在しない場合
        res = ""
    return res
