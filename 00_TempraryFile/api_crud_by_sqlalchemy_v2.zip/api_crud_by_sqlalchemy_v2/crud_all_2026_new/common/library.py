"""
概要: Common Library
更新: 2025/11/13
"""

# 標準ライブラリ
from __future__ import annotations
import os.path
import platform
import shutil
import json


def get_effective_string(s_in: str, min_len: int = 1) -> str:
    """入力文字列を検査し、有効文字列の抽出。文字列長が規定未満の場合、エクセプションを返す。

    Args:
        s_in: 入力文字列
        min_len: 最小の有効文字列長
    Returns:
        str: 有効文字列
    Exceptions:
        TypeError: 入力内容が文字列でない場合
        ValueError: 入力文字列が有効文字列長未満の場合
    """
    if not isinstance(s_in, str):
        raise TypeError(F"Invalid type:{type(s_in)} ")
    if len(s_in.strip()) < min_len:
        raise ValueError(F"Invalid or too short parameter:{repr(s_in)} ")
    return s_in.strip()


def is_windows_platform() -> bool:
    """稼働環境がwindows PFか判定する"""
    return True if "windows" in platform.system().lower() else False


def make_empty_directory(target_dir: str) -> None:
    """指定ディレクトリを空にする。指定ディレクトリが存在しない場合、空ディレクトリを作成する

    Args:
        target_dir: 対象のディレクトリパス（例: dir1/dire2
    """
    if os.path.isdir(target_dir):
        shutil.rmtree(target_dir)
    os.makedirs(target_dir, exist_ok=True)


def jsonfile2dict(json_file: str, *, encoding: str = "utf_8") -> dict | list:
    """指定エンコードのJSONファイルをdict形式に変換する

    Args:
        json_file: JSONファイルパス
        encoding: JSONファイルのエンコーディング ("utf_8" | "utf_8_sig" | "cp932" )
    Returns:
        dict | list: 変換結果
    """
    with open(json_file, mode="r", encoding=encoding) as fin:
        return json.load(fin)


def jsonfile2dict_ex(json_file: str) -> dict | list:
    """JSONファイル(UTF-8 or Shift-JIS形式)をdict形式に変換する

    Args:
        json_file: JSONファイルパス
    Returns:
        dict | list: 変換結果
    """
    support_encoding_list = ["utf_8", "cp932", "utf_8_sig"]
    for encoding in support_encoding_list:
        try:
            return jsonfile2dict(json_file, encoding=encoding)
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue
    raise UnicodeDecodeError


def byte2utf8_str(byte_str: bytes) -> str:
    """バイト文字列(日本語系エンコード)をutf8文字列に変換する

    Args:
        byte_str: 入力のバイト文字列（不明な日本語系エンコード)
    Returns:
        out_str:出力文字列(utf-8)
    """
    support_encoding_list = ["utf_8_sig", "cp932", "euc_jp"]
    for encoding in support_encoding_list:
        try:
            # バイト文字列をutf8文字列に変換する
            utf8_str = byte_str.decode(encoding=encoding).encode('utf-8').decode('utf-8')
        except (UnicodeDecodeError, UnicodeEncodeError):
            print(F"@@ERROR:{encoding=}")
            continue
        else:
            return utf8_str
    raise ValueError("Unsupported encoding")
