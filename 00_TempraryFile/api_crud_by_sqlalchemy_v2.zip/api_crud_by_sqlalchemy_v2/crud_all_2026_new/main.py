"""
概要: API Main Server
更新: 2025/11/07
動作: Readme.md参照
"""

# 標準ライブラリ
import os
import platform
from contextlib import asynccontextmanager
# 拡張ライブラリ
from fastapi import FastAPI, status, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
from loguru import logger
# プライベートライブラリ
from db_crud.database import Database
from common.library import is_windows_platform
from common.lib_setup import setup_loguru, setup_server_directory
from config import ServerConfig
# サブアプリ & サブルータ
from router.api_sample import router_sample
from router.api_item import router_item
from router.api_general_file import router_general_file
from router.api_file import router_file
from main_admin import app as app_admin

# ----------------------------------
#  サーバ全体の初期設定
# ----------------------------------
setup_server_directory()
setup_loguru(log_level=ServerConfig.log_level, log_file=ServerConfig.log_file)
Database.setup_db_table()

# ----------------------------------
#  API サーバ定義
# ----------------------------------
title = "API Server"
version = ServerConfig.version
description = """
### 説明
- 関連リンク: [ADMIN API](admin/docs) : admin/docsへのリンク
"""
responses = {
    status.HTTP_400_BAD_REQUEST: {"description": "BAD_REQUEST"},
    status.HTTP_404_NOT_FOUND: {"description": "NOT_FOUND"},
    status.HTTP_500_INTERNAL_SERVER_ERROR: {"description": "INTERNAL_SERVER_ERROR"},
    status.HTTP_501_NOT_IMPLEMENTED: {"description": "NOT_IMPLEMENTED"},
}


# noinspection PyShadowingNames,PyUnusedLocal
@asynccontextmanager
async def lifespan(app: FastAPI):
    """サーバの起動・シャットダウン処理
    Notes: @app.on_event()は、deprecatedとなっている
    """
    logger.info(F"Start-up Server:{version=}")
    yield
    logger.info("Shut-down Server")


app = FastAPI(title=title, description=description, version=version, lifespan=lifespan, responses=responses)
# -------------------------------------------------
#  CORS定義
# -------------------------------------------------
origins = ["*"]  # Allow all origin
"""
origins = [
    "http://localhost",
    "http://localhost:8080",
]
"""
# noinspection PyTypeChecker
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,  # Allow all origin
    allow_credentials=True,  # Allow cookies
    allow_methods=["*"],  # Allow all method
    allow_headers=["*"],
)


# -------------------------------------------------
#  エンドポイント
# -------------------------------------------------
@app.get("/", summary="Swagger UIへのリダイレクト", include_in_schema=False)
def redirect():
    """Swagger UIへのリダイレクト処理"""
    url = F"/docs"
    logger.info(F"Redirect to:{url}")
    return RedirectResponse(url=url)


@app.get("/ping", summary="ヘルスチェック")
def ping(req: Request):
    """### サーバーのヘルスチェック"""
    res = {
        "platform": platform.platform(),
        "method": req.method,
        "base_url": req.base_url,
        "url": req.url,
        "client": repr(req.client),
    }
    return res


# -------------------------------------------------
# API Router & Admin APP追加
# -------------------------------------------------
app.include_router(router_sample)
app.include_router(router_item)
app.include_router(router_file)
app.include_router(router_general_file)
# 管理用アプリのマウント
app.mount(path="/admin", app=app_admin)

# -------------------------------------------------
#  コマンドラインからのサーバ起動エントリ
# -------------------------------------------------
if __name__ == '__main__':
    import uvicorn

    host = "0.0.0.0"
    if is_windows_platform():
        host = "localhost"
    # 実行ファイル名から拡張子を除いたファイル名を取得し、appの起動名を生成する
    name = os.path.splitext(os.path.basename(__file__))[0]
    app_name = F"{name}:app"
    port = 8000
    logger.info(F"uvicorn.run(app={app_name},{host=},{port=}) on {platform.system()=}")
    uvicorn.run(app=app_name, host=host, port=port, reload=True)
