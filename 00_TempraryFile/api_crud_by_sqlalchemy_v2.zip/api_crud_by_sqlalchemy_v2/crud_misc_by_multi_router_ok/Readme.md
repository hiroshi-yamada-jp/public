# FastAPI CRUD Template pattern#1

## 概要

FastAPI CRUDアプリ(API_Routerで各カテゴリ別に統合)

- DB: SQlite3 DB by sqlalchemy ver2.0 style
- Python: 3.12
- SQLAlchemy: 2.0.x
- Fastapi: 0.116.x(Pydantic 2.11.x)
- 動作結果：OK @2025/07/26

### 機能

- Admin:管理メニュー
- ITEM CRUD
- JsonFile CRUD

### ファイル構成

```
TOP(src)ディレクトリ以下: これをソースルートとしてマーキングしないと、importエラーとしてpycharmで認識される
├─ main.py: APIサーバメインファイル
├─ env(.env): シークレット情報定義.envにリネームする)
├─ logs: ログファイルディレクトリ※ プログラムが動的に作成
├─ sqlite_db: SQLite DBファイルディレクトリ※ プログラムが動的に作成
├─ common: 共通ディレクトリ
    ├─ library.py: 共通ライブラリ
    ├─ config.py: 共通の定数設定
    ├─ db_crud: DB&DB_CRUD&Model用サブディレクトリ
        ├─ crud_file: file Model用CRUD処理
        ├─ crud_item: item Model用CRUD処理
        ├─ database.py: DB定義
├─ router: サブアプリ#1用のrouterディレクトリ
    ├─ api_admin: admin用API
    ├─ api_file: file用API
    ├─ api_item: item用API
├─ schema: サブアプリ#1用のAPIスキーマ定義ディレクトリ
    ├─ schema_file: file api用スキーマ定義
    ├─ schema_item: item api用スキーマ定義
```

### 注意

1. 対象DBは、Sqlite3/MySQL/PostgreSQL。但し、SQlite3のメモリモードは動作しない。
2. DB crudの抽象クラスを作成し、抽象クラスを継承すれことで、CRUD基本メソッドは、継承して使える構成を適用
3. DB crud更新処理は、属性が追加されてもメソッドを変更せずに対応できる仕組みを適用
