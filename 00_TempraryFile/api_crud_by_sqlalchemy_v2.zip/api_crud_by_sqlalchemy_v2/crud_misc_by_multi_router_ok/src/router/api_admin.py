"""
概要: Admin API router
"""

# 標準ライブラリ
from __future__ import annotations
from typing import Literal
import platform
from dataclasses import dataclass, field
# 拡張ライブラリ
from fastapi import APIRouter, Request, Path
from loguru import logger
# プライベートライブラリ
from db_crud.database import Database
from common.config import ServerConfig

# ------------------------------------------
#  Admin用のAPI End point/APIルータ定義
# ポイント: APIRouterの定義によりモデル単位等の共通要素（パス名・タグ名等)定義が可能
# ------------------------------------------
prefix = F"{ServerConfig.api_prefix}/admin"
router_admin = APIRouter(prefix=prefix, tags=['Admin'])
# 管理・デバッグ用の機能メニューのID定義
ServerInfoMenu = Literal["PF", "URL", "DB"]
ServerFuncMenu = Literal["INIT"]


@dataclass
class AdminResponse:
    """Admin APIレスポンス定義"""
    status: str = field(default="OK")
    function: str = field(default=None)
    contents: dict = None


@router_admin.get("/server/{function}", summary="サーバ情報取得")
def get_server_info(
        req: Request,  # システム側で作成されるオブジェクト
        function: ServerInfoMenu = Path(default=..., description="機能名"),
):
    # ポイント: Swagger UIへの表示がマークダウンで記述可能
    """### サーバ情報の取得

    **function**:
    - PF : PF情報
    - URL : URL情報
    - DB : DB情報

    **Note**:
    - None
    """
    logger.info(F'Start:{function=}')
    res = AdminResponse(status="OK", function=function)
    if function == "PF":
        res.contents = {
            "platform": platform.platform(),
            "node": platform.node(),
            "machine": platform.machine(),
            "python_version": platform.python_version(),
        }
    elif function == "URL":
        res.contents = {
            "method": req.method,
            "base_url": req.base_url,
            "url": req.url,
            # ポイント：文字列以外の属性は文字列化しないとエラーとなる
            "headers": str(req.headers),
            "cookies": str(req.cookies),
            "client": str(req.client),
        }
    elif function == "DB":
        res.contents = Database.get_info()
    logger.success(F"End:{res=}")
    return res


@router_admin.post("/db/{function}", summary="データベース初期化")
def db_init(
        function: ServerFuncMenu = Path(default=..., description="実行する機能名"),
):
    """### データベース情報の初期化

    **function**:
    - INIT : DBの各テーブル内の登録データの初期化

    **Note**:
    - Databaseのテーブル情報初期化後はサーバーを再起動すること
    """
    logger.info(F'Start:{function=}')
    res = AdminResponse(status="OK", function=function)
    if function == "INIT":
        Database.initialize_all_table()
        res.contents = Database.get_info()
    logger.success(F"End:{res=}")
    return res
