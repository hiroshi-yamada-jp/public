"""
概要: Item Model APIルータ
"""

# 標準ライブラリ
from __future__ import annotations
from typing import List
# 拡張ライブラリ
from fastapi import HTTPException, Depends, status, APIRouter, Path, Body, Query
from sqlalchemy.orm import Session
from loguru import logger
# プライベートライブラリ
from db_crud.database import get_session
from db_crud.crud_item import Item, ItemCrud
from schema.schema_item import ItemResponse, ItemResponseBase, ItemCreate, ItemUpdate, ItemQuery, DeviceType
from common.config import ServerConfig


# ------------------------------------------------------------
#  API ヘルパー関数
# ------------------------------------------------------------
def get_target_data(session: Session, target_id: int) -> Item:
    """指定IDのデータ取得。指定IDのデータが見つからない場合、エクセプションを発生"""
    if (found_obj := ItemCrud.get(session, target_id)) is None:
        message = F"Invalid {target_id=}"
        logger.error(F"HTTP_404_NOT_FOUND:{message}")
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=message)
    return found_obj


def raise_400_name(name: str) -> None:
    """BAD_REQUESTエクセプションを発生"""
    message = F"{status.HTTP_400_BAD_REQUEST} Invalid name or Duplicate name:{name}"
    logger.error(F"HTTP_400_BAD_REQUEST:{message}")
    raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=message)


# -----------------------------------------------
#  API End point/APIルータ定義
# ポイント: APIRouterの定義によりモデル単位等の共通要素（パス名・タグ名等)定義が可能
# -----------------------------------------------
router_item = APIRouter(prefix=F"{ServerConfig.api_prefix}/item", tags=['Item'])
router_admin_item = APIRouter(prefix=F"{ServerConfig.api_prefix}/admin/item", tags=['Admin Item'])


@router_item.post("/query", summary="データ一覧検索", response_model=List[ItemResponse])
def query(
        session: Session = Depends(get_session),
        params: ItemQuery | None = Body(default=None)
):
    """### データ一覧の絞り込み検索
    """
    logger.info(F"Start:{params=}")
    if params is None:
        params = ItemQuery()
    filters = ItemCrud.set_filter(name=params.name, updated_at=params.updated_at, protect_flag=params.protect_flag)
    obj_list = ItemCrud.query(session, filters=filters)
    logger.success(F"OK:{type(obj_list)}\tlen={len(obj_list)}")
    return obj_list


@router_item.post("/query/simple", summary="データ一覧検索(簡易)", response_model=List[ItemResponseBase])
def query(
        session: Session = Depends(get_session),
        params: ItemQuery | None = Body(default=None)
):
    """### データ一覧の絞り込み検索
    """
    logger.info(F"Start:{params=}")
    if params is None:
        params = ItemQuery()
    filters = ItemCrud.set_filter(name=params.name, updated_at=params.updated_at)
    obj_list = ItemCrud.query(session, filters=filters)
    logger.success(F"OK:{type(obj_list)}\tlen={len(obj_list)}")
    return obj_list


@router_admin_item.post("/create", summary="データ登録", response_model=ItemResponse,
                        status_code=status.HTTP_201_CREATED)
def create(
        session: Session = Depends(get_session),
        params: ItemCreate = Body(default=..., description="登録データ")
):
    """### データの新規登録

    **Notes**
    - 登録名が、DBに登録済の場合、エラーを返す
    """
    logger.info(F"Start:{params=}")
    # nameデータの重複エラー検査 ※ item.nameには、不要文字列を除去したデータが渡されている
    name = params.name
    if ItemCrud.get_by_name(session, target_name=name, exclude_id=None) is not None:
        raise_400_name(name)
    kwargs = params.model_dump()
    new_obj = ItemCrud.create(session, **kwargs)
    logger.success(F"OK:{type(new_obj)}\t{new_obj}")
    return new_obj


@router_item.get("/{target_id}", summary="データ取得", response_model=ItemResponse | None)
def get_by_id(
        session: Session = Depends(get_session),
        target_id: int = Path(..., ge=1)
):
    """### 指定IDのデータ取得

    **Notes**
    - 指定データが見つからない場合、None(null)を返す
    """
    logger.info(F"Start:{target_id=}")
    found_obj = ItemCrud.get(session, target_id)
    logger.success(F"OK:{type(found_obj)}\t{found_obj}")
    return found_obj


@router_item.patch("/{target_id}/device-type", summary="デバイスタイプ更新",
                   response_model=ItemResponse)
def patch_device_type(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1),
        device_type: DeviceType = Query(default=..., description="DeviceTypeを設定"),
):
    """### 指定IDのデータ更新

    **Notes**
    - 指定データが見つからない場合、エラーを返す
    - 更新後の名前が、DBに登録済の場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}\t{device_type=}")
    found_obj = get_target_data(session, target_id)
    params = ItemUpdate(device_type=device_type)
    kwargs = params.model_dump()
    ItemCrud.update(session, target_obj=found_obj, **kwargs)
    logger.success(F"OK:{type(found_obj)}\t{found_obj}")
    return found_obj


@router_admin_item.delete("/{target_id}", summary="データ削除", response_model=ItemResponse)
def delete(
        session: Session = Depends(get_session),
        target_id: int = Path(..., ge=1)
):
    """### 指定IDのデータ削除

    **Notes**
    - 指定データが見つからない場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}")
    found_obj = get_target_data(session, target_id)
    ItemCrud.delete(session, target_obj=found_obj)
    logger.success(F"OK:{type(found_obj)}\t{found_obj}")
    return found_obj


@router_admin_item.put("/{target_id}", summary="データ更新", response_model=ItemResponse)
def update(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1),
        params: ItemUpdate = Body(default=..., description="更新データ(元の内容を維持する属性は、Noneを設定")
):
    """### 指定IDのデータ更新

    **Notes**
    - 指定データが見つからない場合、エラーを返す
    - 更新後の名前が、DBに登録済の場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}\t{params=}")
    found_obj = get_target_data(session, target_id)
    # nameデータの更新指定が有効な場合、nameデータの重複エラー検査 ※ item.nameには、不要文字列を除去したデータが渡される
    name = params.name
    if isinstance(name, str) and ItemCrud.get_by_name(session, target_name=name, exclude_id=found_obj.id) is not None:
        raise_400_name(name)
    kwargs = params.model_dump()
    ItemCrud.update(session, target_obj=found_obj, **kwargs)
    logger.success(F"OK:{type(found_obj)}\t{found_obj}")
    return found_obj
