"""
概要: Common Schema
"""

from __future__ import annotations
# 標準ライブラリ
from datetime import datetime, timedelta, time
# 拡張ライブラリ
from pydantic import BaseModel, Field, model_validator


# -------------------------------------------------------------------------------------------
# APIパラメータ定義
# -------------------------------------------------------------------------------------------
class DatetimeRange(BaseModel):
    """検索用の日時範囲データ"""
    # デフォルトは、昨日の0時0分0秒から明日の0時0分0秒
    start: datetime = Field(default=datetime.combine(datetime.today().date(), time.min) - timedelta(days=1),
                            description="開始日時(省略時はデフォルト値を設定)")
    end: datetime = Field(default=datetime.combine(datetime.today().date(), time.min) + timedelta(days=1),
                          description="終了日時(省略時はデフォルト値を設定)")

    @model_validator(mode="after")
    def validate_relation(self):
        """二つのパラメータの相関検査を行うパターン
        @model_validator(mode="after")でインスタンス化されているので
        self.xxxで各パラメータをアクセスできる
        """
        if self.start > self.end:
            raise ValueError(F"Invalid range:{self}")
        # 元のパラメータ一式を返す
        return self
