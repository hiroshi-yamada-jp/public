"""
概要: JsonFile Model API Schema
"""

from __future__ import annotations
# 標準ライブラリ
from typing import Any
from datetime import datetime
# 拡張ライブラリ
from pydantic import BaseModel, Field
# プライベートライブラリ
from schema.schema_common import DatetimeRange


# -------------------------------------------------------------------------------------------
# APIパラメータ定義
# -------------------------------------------------------------------------------------------
class JsonFileQuery(BaseModel):
    """Query APIパラメータのスキーマ定義"""
    updated_at: DatetimeRange | None = Field(default=None)


# -------------------------------------------------------------------------------------------
#  APIレスポンス定義
#  設計ポイント
#  ・ 原則として、Model定義とAPIレスポンス定義は、独立に定義することで、APIレスポンスではModel定義の一部のみを返す事が可能
#  APIレスポンス定義の利用ポイント
#  ・ モデルとAPIのレスポンス定義は、モデル定義のサブセット構造で定義する
#  ・ xxxResponseBaseはBaseModelを継承し、xxxResponseはxxxResponseBaseを継承して定義する
#  ・ 各APIのresponse_model=xxxでAPIレスポンスを指定することで、crudで同じデータをもらってもAPI毎にレスポンス内容の変更可能
# -------------------------------------------------------------------------------------------
class JsonFileResponseBase(BaseModel):
    """API応答形式定義(基本形)"""
    id: int
    filename: str
    content_type: str
    created_at: datetime
    updated_at: datetime


class JsonFileResponse(JsonFileResponseBase):
    """API応答形式定義 ※ JsonFileResponseBaseを継承することで、追加分を指定する"""
    file_body: Any = Field(default_factory=dict, title="ファイル内容")
