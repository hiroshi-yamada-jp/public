"""
概要: Item Model API Schema
"""

from __future__ import annotations
# 標準ライブラリ
from datetime import datetime
from enum import Enum
# 拡張ライブラリ(v2.x)
from pydantic import BaseModel, Field, field_validator
# プライベートライブラリ
from common.config import DBConfig
from schema.schema_common import DatetimeRange
from common.lib_validator import ValidatorParams as vp


# -------------------------------------------------------------------------------------------
# APIパラメータ定義
# -------------------------------------------------------------------------------------------
# 設計ポイント:
#   - POST(データ作成)とPUT(データ更新)は、以下のポリシーで独立にパラメータ構造を定義する
#   - POST(データ作成)は、必須パラメータはデフォルト値をもたせず、省略可能パラメータはデフォルト値を持たせる構造とする
#   - PUT(データ更新)は、指定が有効な項目のみ更新する仕組みとし、デフォルト値は全てNoneを設定することで、指定項目以外は更新させない
#   - POST/PUTとも原則として、入力パラメータ検証や文字列操作等は、可能な限りvalidatorで行う
#   - データの最大・最小文字列の検査は、定数定義で行う。項目により条件が異なる場合は、その項目のみ個別設定する
#   - Validatorの検証内容が各モデルで重複する場合、バリデーション内容をライブラリ化する
# APIパラメータ定義の利用ポイント:
#   - pydanticでは型チェックを厳密に行うので、データ型の指定は厳密に行うこと(特にNoneの考慮など）
#   - 必須パラメータ指定は、name属性欄参照。オプションパラメータ指定方法は、Optional[xx]がついている属性欄参照。
#   - オプションパラメータ指定では、default値の設定により、指定省略時（項目自体を空にする）のパラメータはdefault値が受け取れる。
#   - パラメータのバリデーション方法(@validator)は下記参照
#       https://pydantic-docs.helpmanual.io/usage/validators/
# SwaggerUI表示の注意
#   - 必須パラメタ(...)を指定時のSwaggerUI表示は型に応じた値が表示される。この場合、項目を正しく手動設定して利用する。
#   - default=Noneを指定時のSwaggerUI表示は型に応じた値が表示される。この場合、対象項目の指定を削除すると、Noneが受け取れる。
# -------------------------------------------------------------------------------------------
class DeviceType(str, Enum):
    UNDEFINE = "UNDEFINE"
    TYPE1 = "TYPE1"
    TYPE2 = "TYPE2"
    TYPE3 = "TYPE3"


# noinspection PyNestedDecorators
class ItemQuery(BaseModel):
    """Query APIパラメータのスキーマ定義"""
    name: str | None = Field(default=None, description="検索条件:部分一致(Noneは検索条件なし)")
    updated_at: DatetimeRange | None = Field(default=None, description="検索条件:更新日時範囲(Noneは検索条件なし)")
    # device_type: DeviceType | None = Field(default=None, description="検索条件:完全一致(Noneは検索条件なし)")
    protect_flag: bool | None = Field(default=None, description="検索条件:完全一致(Noneは検索条件なし)")

    @field_validator('name', mode='before')
    @classmethod
    def is_valid_name(cls, val: str):
        """名前の有効性を検証し、有効文字列を抽出する"""
        return vp.get_effective_string(s_in=val, min_len=1)


# noinspection PyNestedDecorators
class ItemCreate(BaseModel):
    """POST APIパラメータのスキーマ定義:この説明もSwaggerUIに表示される
    ポイント
    ・ default値を設定することで、省略パラメータはデフォルト値で設定される（便利）
    ・ Validatorを使って最小有効文字列長を検証するので、min_lengthの指定不要
    ・ pydantic v2.0では、@field_validatorを使う。
    """
    name: str = Field(..., description="項目名(必須)", max_length=DBConfig.max_length)
    description: str = Field(default="", description="TEXT型(省略時はデフォルト値を設定)")
    protect_flag: bool = Field(default=False, description="Bool型(省略時はデフォルト値を設定)")
    device_type: DeviceType = Field(default=DeviceType.UNDEFINE, description="Enum型(省略時はデフォルト値を設定)")
    # ポイント: ミュータブルなオブジェクトの初期設定は、より安全な実装のため、default_factoryを使って初期設定する
    list_type: list[int] = Field(default=..., description="リスト型整数(各要素は0以上の整数)データ(必須)", min_length=1)
    dict_type: dict = Field(default_factory=dict, description="辞書型データ(省略時はデフォルト値を設定)")

    @field_validator('name', mode='before')
    @classmethod
    def is_valid_name(cls, val: str):
        """名前の有効性を検証し、有効文字列を抽出する"""
        return vp.get_effective_string(s_in=val, min_len=1)

    @field_validator('list_type', mode='after')
    @classmethod
    def is_valid_list(cls, val: list[int]):
        """重複データの検査を行う"""
        return vp.check_int_list(l_in=val, min_v=0, max_v=None)


# noinspection PyNestedDecorators
class ItemUpdate(BaseModel):
    """PUT APIパラメータのスキーマ定義:この説明もSwaggerUIに表示される
    ポイント
    ・ 更新にはデフォルト値にNoneを設定し、指定がない場合、更新させない仕様がよい。ただし、SwaggerUI上は、値が表示される
    ・ Noneを許容するため、最小文字列長は、記載してはいけない。指定が有効な場合、検証関数で有効文字列長を検査する
    """
    name: str | None = Field(default=None, description="項目名(省略時は元の値維持)", max_length=DBConfig.max_length)
    description: str | None = Field(default=None, description="TEXT型(省略時は元の値維持)")
    protect_flag: bool | None = Field(default=None, description="Bool型(省略時は元の値維持)")
    device_type: DeviceType | None = Field(default=None, description="Enum型(省略時は元の値維持)")
    list_type: list[int] | None = Field(default=None, min_length=1,
                                        description="リスト型整数(各要素は0以上の整数)データ(必須)(省略時は元の値維持)")
    dict_type: dict | None = Field(default=None, description="辞書型データ(省略時は元の値維持)")

    @field_validator('name', mode='before')
    @classmethod
    def is_valid_name(cls, val: str | None):
        """名前の有効性を検証し、有効文字列を抽出する"""
        return vp.get_effective_string(s_in=val, min_len=1)

    @field_validator('list_type', mode='after')
    @classmethod
    def is_valid_list(cls, val: list[int]):
        """重複データの検査を行う"""
        return vp.check_int_list(l_in=val, min_v=0, max_v=None)


# -------------------------------------------------------------------------------------------
#  APIレスポンス定義
# -------------------------------------------------------------------------------------------
#  設計ポイント
#  ・ 原則として、Model定義とAPIレスポンス定義は、独立に定義することで、APIレスポンスではModel定義の一部のみを返す事が可能
#  APIレスポンス定義の利用ポイント
#  ・ モデルとAPIのレスポンス定義は、モデル定義のサブセット構造で定義する
#  ・ xxxResponseBaseはBaseModelを継承し、xxxResponseはxxxResponseBaseを継承する
#  ・ 各APIのresponse_model=xxxでAPIレスポンスを指定することで、crudで同じデータをもらってもAPI毎にレスポンス内容の変更可能
# -------------------------------------------------------------------------------------------
class ItemResponseBase(BaseModel):
    """API応答形式(簡易形)
    """
    id: int
    name: str
    description: str


class ItemResponse(ItemResponseBase):
    """API応答形式(Full) ※ ItemResponseを継承することで、追加分を指定する"""
    protect_flag: bool
    device_type: DeviceType
    list_type: list
    dict_type: dict
    created_at: datetime
    updated_at: datetime
