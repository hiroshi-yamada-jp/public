"""
概要: Config情報定義
"""

# 標準ライブラリ
from __future__ import annotations
import os
# 拡張ライブラリ
from dotenv import load_dotenv

load_dotenv()  # .envファイルからシークレット定義の読み込み


class ServerConfig:
    """Server Configuration"""
    api_ver = "v01"
    api_prefix = F"/api/{api_ver}"
    #  ロギング関係
    log_level = "TRACE"  # "TRACE" | "DEBUG" | "INFO"
    log_dir = "logs"
    log_file = F"{log_dir}/server.log"  # ロギングファイル名

    @classmethod
    def get_config(cls) -> dict:
        res = {
            "api_ver": cls.api_ver,
            "api_prefix": cls.api_prefix,
            "log_level": cls.log_level,
            "log_dir": cls.log_dir,
            "log_file": cls.log_file,
        }
        return res


class DBConfig:
    """Database Configuration"""
    max_length = 64
    max_length_l = 1024
    sqlite_mode = True  # True: SQLITE DB  / False: Other RDB (MySQL or PostgreSQL)
    db_path = "sqlite_db"  # SQLite用のDBファイル格納先ディレクトリ

    if sqlite_mode:
        _db_name = "testdb.db"  # DBファイル名
        db_url = F"sqlite:///{db_path}/{_db_name}"
    else:
        _db_name = "testdb"  # DB名
        _db_user = os.getenv("DB_USER")
        _db_pwd = os.getenv("DB_PWD")
        _db_host = 'localhost'  # 接続ホストアドレス or  IP Address
        _db_port = 3306  # 接続ポート番号
        db_url = F"mysql+mysqlconnector://{_db_user}:{_db_pwd}@{_db_host}:{_db_port}/{_db_name}"
        # 参考：postgresqlの場合のURIとエンジン設定は、以下のように行えるはず
        # DB_URL = F"postgresql://{db_user}:{db_pwd}@{_db_host}:{_db_port}/{_db_name}"

    @classmethod
    def get_config(cls) -> dict:
        res = {
            "max_length": cls.max_length,
            "max_length_l": cls.max_length_l,
            "sqlite_mode": cls.sqlite_mode,
            "db_path": cls.db_path,
            "db_url": cls.db_url,
        }
        return res


def test():
    res = ServerConfig.get_config()
    print(F"\nServerConfig.get_config()={type(res)}\n{res}")
    res = DBConfig.get_config()
    print(F"\nDBConfig.get_config()={type(res)}\n{res}")
