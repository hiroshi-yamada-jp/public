"""
概要: APIパラメータの検証用関数
"""
# 標準ライブラリ
from __future__ import annotations


class ValidatorParams:

    @staticmethod
    def get_effective_string(s_in: str | None, min_len: int = 1) -> str | None:
        """入力文字列を検査し、有効文字列の抽出。文字列長が規定未満の場合、エクセプションを返す。

        Args:
            s_in: 入力文字列(Noneの場合、検査不要)
            min_len: 最小の有効文字列長
        Returns:
            str: 有効文字列 / None: 入力内容がNoneの場合
        Exceptions:
            ValueError: 指定文字列が有効文字列未満の場合
        """
        if isinstance(s_in, str):
            if len(s_in.strip()) < min_len:
                raise ValueError(F"Invalid or too short parameter:{repr(s_in)} ")
            return s_in.strip()
        return None

    @staticmethod
    def check_int_list(l_in: list[int] | None, min_v: int | None = None, max_v: int | None = None) -> list[int] | None:
        """入力の整数リストの検査し、エラーの場合、エクセプションとなる

        Args:
            l_in: 入力の整数リスト
            min_v: 整数の最小値。Noneの場合、検査不要
            max_v: 整数の最大値。Noneの場合、検査不要
        Returns:
            list[int]: 検査済の整数リスト / None: 入力内容がNoneの場合
        Exceptions:
            ValueError: 入力リストが整数以外の場合
            ValueError: 範囲指定が有効な場合、入力の整数値が指定範囲外の場合
        """
        if isinstance(l_in, list):
            for v in l_in:
                if not isinstance(v, int):
                    raise ValueError(F"Invalid Input:{v} in {l_in}")
                if isinstance(min_v, int) and v < min_v:
                    raise ValueError(F"Invalid Input:{v} in {l_in}")
                if isinstance(max_v, int) and v > max_v:
                    raise ValueError(F"Invalid Input:{v} in {l_in}")
        return l_in
