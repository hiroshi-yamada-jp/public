"""
概要: 抽象モデル定義とCRUDライブラリ (sqlalchemy 2.0)
参考：
- 【SQLAlchemy】Generic Typesと各種DBの型 対応表: https://zenn.dev/re24_1986/articles/8520ac3f9a0187
"""

# 標準ライブラリ
from __future__ import annotations
from typing import Sequence, Any
from datetime import datetime
from abc import ABC
# 拡張ライブラリ
from sqlalchemy.orm import Session, Mapped, mapped_column
from sqlalchemy import asc, and_, select, String, DateTime, Integer, TEXT
# プライベートライブラリ
from db_crud.database import Base
from common.config import DBConfig
from schema.schema_common import DatetimeRange


# -----------------------------------------------------------------------------------------
#  Model定義: 共通の抽象化定義
# -----------------------------------------------------------------------------------------
class AbstractModel(Base):
    """共通の抽象モデル定義 """
    __abstract__ = True  # 抽象モデル用の記述

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True, unique=True, comment="ID(自動)")
    # nameの重複禁止設定(unique=True)は、アプリ側で対応する実装とする
    name: Mapped[str] = mapped_column(String(DBConfig.max_length), default=..., comment="名称(必須)")
    description: Mapped[str] = mapped_column(TEXT, default="", comment="任意テキスト")
    # 自動作成の作成・更新日時データの設定
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.now,
                                                 comment="作成日時（自動)")
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.now, onupdate=datetime.now,
                                                 comment="更新日時（自動)")


# -----------------------------------------------------------------------------------------
#  CRUD処理の設計ポイント
#  - @staticmethod/@classmethodを使い、利用側がオブジェクト化しなくても基本CRUDを利用可能とする
#    なお、Crud処理をクラスライブラリ化する理由は、利用側が関数を全てimportする手間が省けるため
#  - データ更新は、指定がない（None）パラメータは、更新せず元の値を維持する設計とする、この実装方法は、本コード参照
#  - データ更新は、本コードの実装例のように**kwargsを使い、更新処理が継承側でもそのまま使える実装とする
#  - データ生成は、本コードの実装例のように**kwargsを使い、空データを登録後、各パラメータを更新する処理方法とした
#  - Queryは、実装例のような形で複合条件のQuery検索が可能
#  - SQLAlchemy2.0の新スタイルでは、GET/Queryの書き方が本実装の用に変更となる
# -----------------------------------------------------------------------------------------
class AbstractCrud(ABC):
    """抽象モデルの共通CRUD処理"""
    Model = AbstractModel

    @classmethod
    def set_filter(cls, *, name: str = None, updated_at: DatetimeRange = None):
        """queryメソッド用のfilterデータの設定を行う

        Args:
            name: 検索文字列を含むキーワード(LIKE検索)、Noneの場合は、絞り込みなし
            updated_at: 検索の更新時間レンジを含むキーワード、Noneの場合は、絞り込みなし
        Returns:
            list: 検索条件の設定リスト
        """
        filters = []
        if isinstance(name, str) and name.strip():
            filters.append(cls.Model.name.like(F"%{name}%"))  # 名前が一部一致の場合
        if updated_at is not None:
            filters.append(and_(
                cls.Model.updated_at >= updated_at.start,
                cls.Model.updated_at <= updated_at.end
            ))
        return filters

    @classmethod
    def query(cls, db: Session, filters: list) -> Sequence[Any]:
        """全登録データから検索条件に合致するデータを抽出

        Args:
            db: DBセッション
            filters: 検索条件
        Returns:
            検索結果の一覧リスト
        """
        # ポイント: 複数Queryを設定する汎用的な書き方
        if len(filters) == 0:
            stmt = select(cls.Model).order_by(asc(cls.Model.id))
        else:
            stmt = select(cls.Model).filter(and_(*filters)).order_by(asc(cls.Model.id))
        # ポイント: 全件リストを取得する場合の書き方
        return db.execute(stmt).scalars().all()

    @classmethod
    def get(cls, db: Session, target_id: int) -> Any | None:
        """指定IDのデータ取得

        Args:
            db: DBセッション
            target_id: 取得対象のID番号
        Returns:
            Model:取得データ / None: データが見つからない
        """
        # ポイント: keyレコード委に対するデータ取得の書き方
        return db.get(cls.Model, target_id)

    @classmethod
    def get_by_name(cls, db: Session, target_name: str, exclude_id: int or None) -> Any | None:
        """指定データ(by name)の取得。オプションとして検索対象から除外するidを指定可能
        Args:
            db: DBセッション
            target_name: 検索対象名
            exclude_id: 検索から除外するid / None: 除外するidの指定無効
        Returns:
            Model:取得データ / None: データが見つからない
        """
        # ポイント：検索結果が1件またはNoneとなる場合、first()ではなくone_or_none()を使うのがベター
        name = target_name.strip()
        if exclude_id is None:
            stmt = select(cls.Model).filter(cls.Model.name == name)
        else:
            stmt = select(cls.Model).filter(cls.Model.name == name).filter(cls.Model.id != exclude_id)
        return db.execute(stmt).scalars().one_or_none()
        # return db.execute(stmt).one_or_none()

    @classmethod
    def create(cls, db: Session, **kwargs: dict[str, Any]) -> Model:
        """指定データの新規登録

        Args:
            db: DBセッション
            kwargs:データ登録内容 例: {"name" : "登録名","description": "説明内容"}
        Returns:
            Model:登録データ
        """
        # 下記実装だと、一時的に名前が重なるため、DBのNameエントリにunique制約をつけることはできない。
        new_obj = cls.Model()
        db.add(new_obj)
        return cls.update(db, target_obj=new_obj, **kwargs)

    @classmethod
    def update(cls, db: Session, target_obj, **kwargs: dict[str, Any]) -> Any:
        """指定データの更新

        Args:
            db: DBセッション
            target_obj: 操作対象のデータオブジェクト
            kwargs:データ登録内容 例: {"name" : "登録名","description": None}

        Returns:
            Model:更新データ
        """
        for key, up_val in kwargs.items():
            if up_val is not None and hasattr(target_obj, key):
                setattr(target_obj, key, up_val)
        # DBに更新内容を登録し、リフレッシュする
        db.commit()
        db.refresh(target_obj)
        return target_obj

    @staticmethod
    def delete(db: Session, target_obj) -> None:
        """指定データの削除

        Args:
            db: DBセッション
            target_obj: 操作対象のデータオブジェクト
        Returns:
            None
        """
        db.delete(target_obj)
        db.commit()
