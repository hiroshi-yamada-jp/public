"""
概要: SQlite DB定義 (sqlalchemy)
Notes: SQLAlchemy 2.0対応の書き方
 - FastAPI+SQLAlchemyで非同期WebAPI(https://www.rhoboro.com/2021/06/12/async-fastapi-sqlalchemy.html)
"""

# 標準ライブラリ
from __future__ import annotations
import os
# 拡張ライブラリ
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase
# プライベートライブラリ
from common.config import DBConfig

# ---------------------------------------------
#  初期設定・ファンクション定義
# ---------------------------------------------
db_echo = False  # DBログのエコーモード

if DBConfig.sqlite_mode:
    db_engine = create_engine(DBConfig.db_url, echo=db_echo, connect_args={"check_same_thread": False})
else:
    # ポイント: pool_pre_ping:プールのコネクション時にpingでActive状態を確認するので、接続切れによるエラーを回避可能
    db_engine = create_engine(DBConfig.db_url, echo=db_echo, pool_pre_ping=True)

# 以下の正確な動作は理解不足
SessionLocal = sessionmaker(bind=db_engine, autocommit=False, autoflush=False)


# ポイント: SQLAlchemy2.0 StyleのBase定義方法
class Base(DeclarativeBase):
    pass


def get_session():
    """各リクエスト毎のDBセッション管理"""
    session = SessionLocal()  # 新規セッションインスタンスの生成
    try:
        # FastAPI呼び出し元にセッションを渡し、処理完了後に後処理を行う
        yield session
    except Exception as e:
        # FastAPIエンドポイント側でException発生時は、処理をロールバック後に、例外を上位に返す
        session.rollback()
        raise e
    finally:
        # 例外発生時も、正常処理時も必ずセッションをクローズする
        session.close()


# ポイント: オブジェクト化しなくても利用可能なクラス定義
class Database:
    """SQLite3用データベースクラス """

    @staticmethod
    def setup_db_table() -> None:
        """DB格納ディレクトリとDBテーブルの作成。作成済の場合は、何もしない"""
        if DBConfig.sqlite_mode:
            os.makedirs(DBConfig.db_path, exist_ok=True)
        Base.metadata.create_all(db_engine)

    @classmethod
    def initialize_all_table(cls) -> None:
        """データベース初期化: DB内のテーブルの初期化"""
        Base.metadata.drop_all(db_engine)
        cls.setup_db_table()

    @staticmethod
    def get_info() -> dict:
        """データベース設定情報の取得"""
        res = {
            "DBConfig": DBConfig.get_config(),
            "db_engine": repr(db_engine),
            "db_engine.pool.status()": db_engine.pool.status(),
        }
        return res
