"""
概要: FileModel & CRUD
更新: 2026/2/17
"""

# 標準ライブラリ
from __future__ import annotations
# 拡張ライブラリ
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy import LargeBinary, BOOLEAN, String, Enum
# プライベートライブラリ
from db_crud.crud_abstract import AbstractModel, AbstractCrud, MAX_LEN
from schema.schema_file import FileCategory


class FileModel(AbstractModel):
    """モデル定義 ※ 抽象クラスの継承なので、追加または更新属性定義が必要"""
    __tablename__ = 'file_model_tool'  # テーブル名は任意

    # ファイルの中身はバイナリで保存し、内容を取得時にテキストやJSONに変換する方法をとる
    read_only: Mapped[bool] = mapped_column(BOOLEAN, default=False, comment="True=Read Only/False:RW")
    file_category: Mapped[FileCategory] = mapped_column(Enum(FileCategory), default=FileCategory.UNKNOWN,
                                                        comment="ファイルカテゴリ")
    keyword: Mapped[str] = mapped_column(String(MAX_LEN), default="", comment="任意キーワード")
    file_body: Mapped[bytes] = mapped_column(LargeBinary, default=None, comment="ファイル内容（バイナリ)")


class FileCrud(AbstractCrud):
    """File Model CRUD処理 ※ 抽象クラスの継承なので、追加または更新属性定義が必要"""
    Model = FileModel
