"""
概要: Admin Mode API 用サーバー
更新: 2026/02/20
"""

# 標準ライブラリ
import os
# 拡張ライブラリ
from fastapi import FastAPI
# プライベートライブラリ
from config import ServerConfig
# サブルータ
from router.api_server import router_server_admin
from router.api_file import router_file_admin

# ----------------------------------
#  API サーバ定義
# ----------------------------------
title = "[Admin]File API"

version = ServerConfig.version
description = """
### 注意事項
- [Admin]カテゴリのAPIは、解析用の非公開APIであり、利用禁止（動作保証対象外)
"""
app = FastAPI(title=title, description=description, version=version)

# -------------------------------------------------
# Admin API Router追加
# -------------------------------------------------
admin_api_enable = True
app.include_router(router_server_admin, include_in_schema=admin_api_enable)
app.include_router(router_file_admin, include_in_schema=admin_api_enable)

# -------------------------------------------------
#  コマンドラインからのサーバ起動エントリ
# -------------------------------------------------
if __name__ == '__main__':
    import uvicorn

    # 実行ファイル名から拡張子を除いたファイル名を取得し、appの起動名を生成する
    name = os.path.splitext(os.path.basename(__file__))[0]
    app_name = F"{name}:app"
    host = "localhost"
    uvicorn.run(app=app_name, host=host, port=8010, reload=True)
