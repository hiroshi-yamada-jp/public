"""
概要: File model APIルータ
更新: 2026/2/20
"""

# 標準ライブラリ
from __future__ import annotations
# 拡張ライブラリ
from fastapi import Depends, APIRouter, Path, Query, UploadFile, File
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from loguru import logger
import polars as pl
# プライベートライブラリ
from db_crud.database import get_session
from db_crud.crud_file import FileModel, FileCrud
from db_crud.crud_abstract import Operand
from schema.schema_common import CommonResponse
from schema.schema_file import FileModelResponse, FileModelRegister, FileCategory, FileCsvMenu, FileTextMenu
from helper.helper_api_common import ApiExceptionHelper
from helper.helper_file import HelperFile, HelperFileRegister


# ------------------------------------------------------------
#  ローカル関数、定数定義
# ------------------------------------------------------------
def get_target_model(db: Session, target_id: int) -> FileModel:
    """指定IDのファイルモデル取得。指定ファイルが見つからない場合、エクセプションとなる"""
    if (found_obj := FileCrud.get(db, target_id=target_id)) is None:
        message = F"不正ID:{target_id=}"
        ApiExceptionHelper.raise_http_404(message=message)
    return found_obj


def validate_read_only(target_model: FileModel) -> None:
    """指定IDのファイルがRW可能なこと検査する。ROの場合、エクセプションとなる"""
    helper = HelperFile(file_model=target_model)
    if helper.is_read_only():
        message = F"Read Onlyファイルはファイル更新、削除はできません"
        ApiExceptionHelper.raise_http_400(message=message)


def get_spo_df(db: Session, target_id: int) -> pl.DataFrame:
    """指定IDのファイルモデルからSPOデータフレームを取得する"""
    file_model = get_target_model(db, target_id=target_id)
    return HelperFile(file_model=file_model).file_body2df(max_lines=0)


# -----------------------------------------------
#  File API End point/APIルータ定義
# -----------------------------------------------
router_file = APIRouter(prefix="/file", tags=['File'])
router_file_admin = APIRouter(prefix="/file", tags=['[Admin]File'])


@router_file.post("/query", summary="ファイル一覧", response_model=list[FileModelResponse])
@router_file_admin.post("/query", summary="ファイル一覧", response_model=list[FileModelResponse])
def query(
        session: Session = Depends(get_session),
        name: str | None = Query(default="name", description="検索属性"),
        value: str | None = Query(default=None, description="検索値"),
        operand: Operand = Query(default=Operand.LIKE, description="検索式"),
):
    """### ファイル一覧の検索
    - 検索条件の値設定により、データ絞り込みが可能

    **Notes**
    - value欄がNone(null)の場合、Query検索は無効となる
    - name欄に有効な属性名を指定しないと、Query検索は有効とならない
    - 検索属性と検索式の種類の組み合わせによっては、予期せぬ結果となる場合がある
    """
    logger.info(F"Start:{name=}\t{value=}\t{operand=}")
    filters = FileCrud.set_filter(name=name, value=value, operand=operand)
    res = FileCrud.query(session, filters=filters)
    logger.success(F"OK:{type(res)}\tlen={len(res)}")
    return res


@router_file.post("/upload", summary="ファイルアップロード（登録)", response_model=FileModelResponse)
@router_file_admin.post("/upload", summary="ファイルアップロード（登録)", response_model=FileModelResponse)
def upload_file(
        session: Session = Depends(get_session),
        file: UploadFile = File(default=..., description="登録ファイル"),
        file_category: FileCategory = Query(default=FileCategory.UNKNOWN, description="登録ファイルの種別")
):
    """### アップロードファイルをファイルモデルとして（新規または更新)登録する
    - アップロードしたファイルをDBに登録し、併せてサーバ内部のディレクトリに保存する

    **Notes**
    - 登録ファイル名と同じ名前が既にDB上に登録済の場合、ファイル内容は更新登録となる
    - ファイルの更新登録において、ファイルがRead Onlyモードに設定されている場合、エラーとなる
    - ファイルカテゴリに対して、アップロードファイルのMIMEタイプが合致しない場合、エラーとなる
    - ファイルカテゴリは、MIMEタイプ検査のみ行っているので、ファイルの中身がカテゴリに対して正しい保証はない
    """
    logger.info(F"Start:{file_category=}\t{file.filename=}\t{file.content_type=}\tfile_body={type(file.file)}")
    # 指定ファイル名のモデルがリードオンリーでないことを確認する
    if (target_model := FileCrud.get_by_name(session, target_name=file.filename)) is not None:
        validate_read_only(target_model=target_model)
    helper = HelperFileRegister(file=file, file_category=file_category)
    if not helper.is_valid_file_category():
        message = F"不正MIMEタイプ:{file_category=} for {file.content_type=}"
        ApiExceptionHelper.raise_http_400(message=message)
    # アップロードファイルを所定ディレクトリにコピーして、読み込む
    try:
        file_body = helper.create_upload_file()
    except Exception as e:
        message = F"ファイルエラー:{type(e)}\t{e.args=}"
        ApiExceptionHelper.raise_http_500(message=message)
    # ファイルをDBに登録する
    attribute = helper.get_file_attribute()
    kwargs = FileModelRegister(
        file_body=file_body,
        attribute=attribute,
        read_only=False,
        keyword=None,
        file_category=file_category,
    ).model_dump()
    res = FileCrud.register(session, name=file.filename, **kwargs)
    logger.success(F"End:ID={res.id}\t{res.name=}\t{res.attribute=}")
    return res


@router_file.post("/download/{target_id}", summary="ファイルダウンロード")
@router_file_admin.post("/download/{target_id}", summary="ファイルダウンロード")
def download_file(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1, description="対象ID"),
):
    """### 指定IDのファイル登録内容をダウンロードする

    **Notes**
    - 指定IDのファイルモデルが見つからない場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}")
    target_model = get_target_model(session, target_id=target_id)
    helper = HelperFile(file_model=target_model)
    file_path = helper.get_download_file()
    media_type = helper.get_contents_type()
    logger.success(F"OK:{file_path=}\t{media_type=}")
    return FileResponse(file_path, media_type=media_type, filename=target_model.name)


@router_file.post("/is-same-file/{target_id}/{target_id2}", summary="二つのファイル内容の一致検査")
def is_same_file(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., description="対象ID", ge=1),
        target_id2: int = Path(default=..., description="対象ID"),
):
    """### 指定した二つのファイル登録内容が一致するか検査する

    **Notes**
    - 指定IDのファイルモデルが見つからない場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}\t{target_id2=}")
    target_model1 = get_target_model(session, target_id=target_id)
    target_model2 = get_target_model(session, target_id=target_id2)
    # helper1 = HelperFile(file_model=target_model1)
    # helper2 = HelperFile(file_model=target_model2)
    attribute = {
        "file1": target_model1.attribute,
        "file2": target_model2.attribute,
    }
    res = CommonResponse(
        status=False,
        attribute=attribute,
        contents=None
    )
    if target_model1.file_body == target_model2.file_body:
        res.status = True
    logger.success(F"OK:{type(res)}\t{res=}")
    return res


@router_file.get("/{target_id}", summary="ファイルモデル取得", response_model=FileModelResponse)
@router_file_admin.get("/{target_id}", summary="ファイルモデル取得", response_model=FileModelResponse)
def get(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1, description="対象ID"),
):
    """### 指定IDのファイルモデルの取得

    **Notes**
    - 指定IDのファイルモデルが見つからない場合、エラーを返す
    - 本APIでは、ファイル内容は返さない。ファイル内容の取得は別APIで行う。
    """
    logger.info(F"Start:{target_id=}")
    res = get_target_model(session, target_id)
    logger.success(F"OK:ID={res.id}\t{res.name=}")
    return res


@router_file.get("/{target_id}/contents-as-text", summary="ファイル内容取得(テキスト)")
@router_file_admin.get("/{target_id}/contents-as-text", summary="ファイル内容取得(テキスト)")
def get_as_text(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1, description="対象ID"),
        max_lines: int = Query(default=5, ge=0, description="先頭からn行取得(0:全行)"),
        menu_type: FileTextMenu = Query(default=FileTextMenu.TEXT, description="表示形式")
):
    """### 指定IDのファイル登録内容をテキスト形式で取得

    **Notes**
    - 指定IDのファイルモデルが見つからない場合、エラーを返す
    - ファイルがテキスト変換できない場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}\t{max_lines=}")
    target_model = get_target_model(session, target_id=target_id)
    if menu_type == FileTextMenu.LIST:
        res = HelperFile(file_model=target_model).file_body2text_list(max_lines=max_lines)
    else:
        res = HelperFile(file_model=target_model).file_body2text(max_lines=max_lines)
    if res is None:
        message = F"不正テキストファイル:{target_id=}"
        ApiExceptionHelper.raise_http_400(message=message)
    logger.success(F"OK:{type(res)}\t{len(res)=}")
    return res


@router_file.get("/{target_id}/contents-as-json", summary="ファイル内容取得(JSON形式)")
@router_file_admin.get("/{target_id}/contents-as-json", summary="ファイル内容取得(JSON形式)")
def get_as_json(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1, description="対象ID"),
):
    """### 指定IDのファイル登録内容をJSONデータに変換して取得

    **Notes**
    - 指定IDのファイルモデルが見つからない場合、エラーを返す
    - ファイルがJSON変換できない場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}")
    target_model = get_target_model(session, target_id=target_id)
    try:
        res = HelperFile(file_model=target_model).file_body2json()
    except Exception as e:
        message = F"不正JSONファイル:{type(e)}\t{e.args=}"
        ApiExceptionHelper.raise_http_400(message=message)
    logger.success(F"OK:{type(res)}\t{res}")
    return res


@router_file.get("/{target_id}/contents-as-csv", summary="ファイル内容取得(CSV形式)")
@router_file_admin.get("/{target_id}/contents-as-csv", summary="ファイル内容取得(CSV形式)")
def get_as_csv(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1, description="対象ID"),
        max_lines: int = Query(default=5, ge=0, description="先頭からn行取得(0:全行)"),
        menu_type: FileCsvMenu = Query(default=FileCsvMenu.TEXT, description="表示形式")
):
    """### 指定IDのファイル登録内容をCSV形式にして出力

    **Notes**
    - 指定IDのファイルモデルが見つからない場合、エラーを返す
    - ファイルがCSV形式に変換できない場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}\t{max_lines=}\t{menu_type=}")
    target_model = get_target_model(session, target_id=target_id)
    if (df := HelperFile(file_model=target_model).file_body2df(max_lines=max_lines)) is None:
        message = F"不正CSVファイル:{target_id=}"
        ApiExceptionHelper.raise_http_400(message=message)
    # データフレームを行単位のリストに変換する
    if menu_type == FileCsvMenu.LIST:
        res = df.to_dicts()
    else:
        res = df.write_csv(file=None)
    logger.success(F"OK:{type(res)}\t{len(res)=}")
    return res


@router_file.delete("/{target_id}", summary="ファイルモデル削除", response_model=FileModelResponse)
@router_file_admin.delete("/{target_id}", summary="ファイルモデル削除", response_model=FileModelResponse)
def delete(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1, description="対象ID"),
):
    """### 指定IDのファイルモデル削除

    **Notes**
    - 指定IDのファイルモデルが見つからない場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}")
    res = get_target_model(session, target_id=target_id)
    # 本モデルが削除可能か検査する
    validate_read_only(target_model=res)
    # DBモデルと一緒にDB登録時に所定ディレクトリにアップロードされたファイルも削除する
    helper = HelperFile(file_model=res)
    helper.remove_upload_file()
    FileCrud.delete(session, target_obj=res)
    logger.success(F"OK:{res.id=}\t{res.name=}")
    return res


@router_file.patch("/{target_id}", summary="ファイル属性の更新", response_model=FileModelResponse)
@router_file_admin.patch("/{target_id}", summary="ファイル属性の更新", response_model=FileModelResponse)
def patch(
        session: Session = Depends(get_session),
        target_id: int = Path(default=..., ge=1, description="対象ID"),
        read_only: bool | None = Query(default=None, description="ファイルアクセス:True=RO/False:RW"),
        keyword: str | None = Query(default=None, comment="ファイル識別用のタグ情報"),
):
    """### 指定IDのファイルモデルの一部属性を更新する

    **Notes**
    - 指定IDのファイルモデルが見つからない場合、エラーを返す
    """
    logger.info(F"Start:{target_id=}\t{read_only=}\t{keyword=}")
    target_model = get_target_model(session, target_id=target_id)
    kwargs = FileModelRegister(
        read_only=read_only,
        keyword=keyword,
    ).model_dump()
    res = FileCrud.update(session, target_obj=target_model, **kwargs)
    logger.success(F"OK:{res.id=}\t{res.name=}")
    return res
