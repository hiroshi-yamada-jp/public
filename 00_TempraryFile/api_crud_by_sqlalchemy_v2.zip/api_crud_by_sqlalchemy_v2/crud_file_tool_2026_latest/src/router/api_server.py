"""
概要: システム汎用APIルータ
更新: 2026/2/17
"""

# 標準ライブラリ
from __future__ import annotations
import platform
# 拡張ライブラリ
from fastapi import APIRouter, Request, Path
from loguru import logger
# プライベートライブラリ
from db_crud.database import Database
from schema.schema_server import ServerMenu, DatabaseMenu, DirMenu
from schema.schema_common import CommonResponse, CommonDirContents
from helper.helper_api_common import ApiExceptionHelper
from config import ServerConfig, DBConfig
from common.lib_dir import get_filename_in_directory, make_empty_directory


# ------------------------------------------
#  local関数
# ------------------------------------------
def __get_directory_contents(target_directory: str) -> CommonDirContents:
    files = get_filename_in_directory(target_directory)
    contents = CommonDirContents(
        directory=target_directory,
        file_count=len(files),
        files=files,
    )
    return contents


# ------------------------------------------
#  Admin用のAPI End point/APIルータ定義
# ------------------------------------------
prefix = "/server"

router_server = APIRouter(prefix=prefix, tags=['Server'])
router_server_admin = APIRouter(prefix=prefix, tags=['[Admin]Server'])


@router_server.get("/show/{function}", summary="サーバ情報表示", response_model=CommonResponse)
@router_server_admin.get("/show/{function}", summary="サーバ情報表示", response_model=CommonResponse)
def show_server(req: Request, function: ServerMenu = Path(default=..., description="機能名"), ):
    """### サーバ情報の表示

    **function**
    - Platform : Platform情報の表示
    - URL : URL情報の表示
    - Config : Config情報の表示

    **Note**:
    - None
    """
    logger.info(F'Start:{function=}')
    res = CommonResponse(status=True, attribute=function)
    if function == ServerMenu.F_PF:
        res.contents = {
            "platform": platform.platform(),
            "node": platform.node(),
            "machine": platform.machine(),
            "python_version": platform.python_version(),
        }
    elif function == ServerMenu.F_URL:
        res.contents = {
            "method": req.method,
            # ポイント：文字列以外の属性は文字列化しないとエラーとなる
            "base_url": str(req.base_url),
            "url": str(req.url),
            "headers": str(req.headers),
            "cookies": str(req.cookies),
            "client": str(req.client),
        }
    elif function == ServerMenu.F_CONFIG:
        res.contents = {
            "server": ServerConfig.show_config(),
            "database": DBConfig.show_config(),
        }
    else:
        message = F"不正ファンクション:{function=}"
        ApiExceptionHelper.raise_http_400(message=message)
    logger.success(F"End:{res=}")
    return res


@router_server.get("/show-dir/{dir_name}", summary="ディレクトリ情報表示", response_model=CommonResponse)
@router_server_admin.get("/show-dir/{dir_name}", summary="ディレクトリ情報表示", response_model=CommonResponse)
def show_directory(dir_name: DirMenu = Path(default=..., description="対象ディレクトリ"), ):
    """### サーバ内の指定ディレクトリ情報の表示

    **Note**:
    - None
    """
    logger.info(F'Start:{dir_name=}')
    if dir_name == DirMenu.DIR_TEMP:
        target_directory = ServerConfig.temp_dir
    elif dir_name == DirMenu.DIR_UPLOAD:
        target_directory = ServerConfig.upload_dir
    elif dir_name == DirMenu.DIR_LOG:
        target_directory = ServerConfig.log_dir
    else:
        message = F"不正ディレクトリ:{dir_name=}"
        ApiExceptionHelper.raise_http_400(message=message)
    contents = __get_directory_contents(target_directory=target_directory)
    res = CommonResponse(status=True, attribute=dir_name, contents=contents)
    logger.success(F"End:{res=}")
    return res


@router_server.post("/init-dir/{dir_name}", summary="ディレクトリ初期化", response_model=CommonResponse)
@router_server_admin.post("/init-dir/{dir_name}", summary="ディレクトリ初期化", response_model=CommonResponse)
def init_directory(dir_name: DirMenu = Path(default=..., description="対象ディレクトリ"), ):
    """### サーバ内の指定ディレクトリの初期化

    **Note**:
    - UPLOAD_DIRの初期化は、必ずDBテーブルも初期化し、同期をとること
    - LOGディレクトリの初期化は、サーバでアクセス中のログファイルは、削除できない
    """
    logger.info(F'Start:{dir_name=}')
    if dir_name == DirMenu.DIR_TEMP:
        target_directory = ServerConfig.temp_dir
    elif dir_name == DirMenu.DIR_UPLOAD:
        target_directory = ServerConfig.upload_dir
    elif dir_name == DirMenu.DIR_LOG:
        target_directory = ServerConfig.log_dir
    else:
        message = F"不正ディレクトリ:{dir_name=}"
        ApiExceptionHelper.raise_http_400(message=message)
    try:
        make_empty_directory(target_directory)
        status = True
    except Exception as e:
        logger.error(F"{type(e)}\t{e.args=}")
        status = False
    # 初期化後のディレクトリ内容を返す
    contents = __get_directory_contents(target_directory=target_directory)
    res = CommonResponse(status=status, attribute=dir_name, contents=contents)
    logger.success(F"End:{res=}")
    return res


@router_server.get("/show-db/{function}", summary="DB情報表示", response_model=CommonResponse)
@router_server_admin.get("/show-db/{function}", summary="DB情報表示", response_model=CommonResponse)
def get_db_info(function: DatabaseMenu = Path(default=..., description="機能名")):
    """### DB情報の表示

    **function**
    - Database: DBステータスの表示
    - Table: DBテーブルの表示

    **Note**:
    - 特になし
    """
    logger.info(F'Start:{function=}')
    res = CommonResponse(status=True, attribute=function)
    if function == DatabaseMenu.DB_STATUS:
        res.contents = Database.get_info()
    elif function == DatabaseMenu.DB_TABLE:
        res.contents = Database.get_all_table_list()
    else:
        message = F"不正ファンクション:{function=}"
        ApiExceptionHelper.raise_http_400(message=message)
    logger.success(F"End:{res=}")
    return res


@router_server.post("/initialize-db", summary="DB初期化", response_model=CommonResponse)
@router_server_admin.post("/initialize-db", summary="DB初期化", response_model=CommonResponse)
def init_db_table():
    """### [開発専用]:データベースの全テーブルを初期化

    **Note**:
    - Database初期化時は、DBとの同期をとるため併せてUPLOAD DIR以下のファイルも初期化する
    - Database初期化後はサーバーを再起動すること
    """
    logger.warning(F'Start')
    function = "Initialize_DB"
    res = CommonResponse(status=True, attribute=function)
    Database.initialize_all_table()
    res.contents = Database.get_info()
    dir_path = ServerConfig.upload_dir
    make_empty_directory(dir_path)
    logger.info(F"Initialize upload directory:{dir_path=}")
    logger.success(F"End:{res=}")
    return res


'''
@router_server_admin.post("/db/init_table/{table_name}", summary="[DEV]DBの指定テーブル初期化",
                          response_model=CommonResponse)
def init_db_table(table_name: InitTableMenu = Path(default=..., description="初期化対象のテーブル名")):
    """### [開発専用]:データベースの指定テーブルを初期化

    **Note**:
    - テスト目的以外の利用は、一切禁止
    - テーブル初期化後はサーバーを再起動すること
    """
    logger.warning(F'Start:{table_name=}')
    table_list = []
    if table_name == InitTableMenu.TB_FILE:
        table_list = [FileModel.__table__]
    elif table_name == InitTableMenu.TB_FILE_SPO:
        table_list = [SpoFileModel.__table__]
    else:
        message = F"不正テーブル名:{table_name=}"
        ApiExceptionHelper.raise_http_400(message=message)
    function = F"Initialize_table:{repr(table_name)}"
    res = CommonResponse(status=True, attribute=function)
    Database.initialize_target_table(table_list=table_list)
    res.contents = Database.get_info()
    logger.success(F"End:{res=}")
    return res
'''
