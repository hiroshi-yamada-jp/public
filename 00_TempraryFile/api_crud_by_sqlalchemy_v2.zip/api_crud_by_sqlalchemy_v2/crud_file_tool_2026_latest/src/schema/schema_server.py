"""
概要: ServerAPIのスキーマ定義
更新: 2026/2/13
"""

# 標準ライブラリ
from __future__ import annotations
from enum import Enum


# ------------------------------
# APIパラメータ定義
# ------------------------------
class ServerMenu(str, Enum):
    """サーバ表示用定義"""
    F_PF = "Platform"
    F_URL = "URL"
    F_CONFIG = "Config"


class DirMenu(str, Enum):
    """ディレクトリ表示・初期化メニュー定義"""
    DIR_UPLOAD = "UPLOAD"
    DIR_TEMP = "TEMP"
    DIR_LOG = "LOG"


class DatabaseMenu(str, Enum):
    """データベース表示用定義"""
    DB_STATUS = "Database"
    DB_TABLE = "Table"
