"""
概要: File Model Schema
更新: 2026/2/20
"""

# 標準ライブラリ
from __future__ import annotations
from datetime import datetime
from enum import Enum
# 拡張ライブラリ
from pydantic import BaseModel, Field


# ------------------------------------------
#  汎用属性定義
# ------------------------------------------
class FileCategory(str, Enum):
    """ファイル種別"""
    UNKNOWN = "UNKNOWN"  # 不定形式
    TEXT = "TEXT"
    CSV = "CSV"
    JSON = "JSON"


class FileAttribute(BaseModel):
    filename: str = Field(default="", description="アップロード時のファイル名")
    content_type: str = Field(default="", description="アップロード時のコンテンツタイプ)")
    size: int = Field(default=0, description="アップロード時のファイルサイズ")
    # header: str | None = Field(default=None, description="アップロード時のファイルヘッダ") # 不要な情報のため、削除
    file_path: str | None = Field(default=None, description="アップロード時の保存ファイルパス")


class FileModelRegister(BaseModel):
    """Fileモデル登録用構造定義"""
    attribute: FileAttribute | None = Field(default=None, description="ファイル属性")
    read_only: bool | None = Field(default=None, description="")
    file_category: FileCategory | None = Field(default=None, description="ファイル分離情報")
    keyword: str | None = Field(default=None, description="任意キーワード")
    file_body: bytes | str | None = Field(default=None, description="ファイル内容")


# ------------------------------------------
#  APIパラメータ定義
# ------------------------------------------
class FileTextMenu(str, Enum):
    """テキストファイル用の表示メニュー"""
    TEXT = "text"  # テキスト形式
    LIST = "list[str]"  # リスト形式


class FileCsvMenu(str, Enum):
    """CSVファイル用の表示メニュー"""
    TEXT = "csv_text"  # テキスト形式
    LIST = "list[dict]"  # リスト形式


# ------------------------------------------
#  APIレスポンス定義
# ------------------------------------------
class FileModelResponse(BaseModel):
    """API応答形式定義(基本形)"""
    id: int
    name: str
    attribute: dict
    read_only: bool
    file_category: FileCategory
    keyword: str
    created_at: datetime
    updated_at: datetime


class FileModelResponseFull(FileModelResponse):
    """API応答形式定義 ※ FileResponseBaseを継承することで、追加分を指定する"""
    file_body: str | bytes
