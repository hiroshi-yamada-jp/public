"""
概要: 共通スキーマ定義
更新: 2026/2/13
"""

# 標準ライブラリ
from __future__ import annotations
from typing import Any
# 拡張ライブラリ
from pydantic import BaseModel, Field


# ------------------------------
#  APIのレスポンス定義
# ------------------------------
class CommonResponse(BaseModel):
    """Common APIレスポンス定義"""
    status: bool = Field(default=False, description="True:OK/False:NG")
    attribute: Any = Field(default=None, description="任意タイプの属性")
    contents: Any = Field(default=None, description="実行結果")


class CommonDirContents(BaseModel):
    """所定ディレクトリ内のファイル一覧"""
    directory: str = Field(default=None, description="ディレクトリ名")
    file_count: int = Field(default=-1, description="ファイル数")
    files: list = Field(default_factory=list, description="ファイル名一覧")
