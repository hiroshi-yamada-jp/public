"""
概要: API Main Server
更新: 2026/02/20
"""

# 標準ライブラリ
import os
import platform
from contextlib import asynccontextmanager
# 拡張ライブラリ
from fastapi import FastAPI, status, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
from loguru import logger
# プライベートライブラリ
from db_crud.database import Database
from common.lib_setup import setup_loguru, setup_server_directory, is_windows_platform
from config import ServerConfig
# サブルータ
from router.api_server import router_server
from router.api_file import router_file
# サブアプリ
from main_admin import app as app_admin

# ----------------------------------
#  サーバ動作の初期設定
# ----------------------------------
setup_server_directory()
# サーバロギングの初期設定
setup_loguru(log_level=ServerConfig.log_level, log_file=ServerConfig.log_file)
# データベースの初期設定
Database.setup_db_table()

# ----------------------------------
#  API サーバ定義
# ----------------------------------
title = "File API"
version = ServerConfig.version
description = F"""
### 注意事項
- TBD
"""
responses = {
    status.HTTP_400_BAD_REQUEST: {"description": "BAD_REQUEST"},
    status.HTTP_404_NOT_FOUND: {"description": "NOT_FOUND"},
    status.HTTP_500_INTERNAL_SERVER_ERROR: {"description": "INTERNAL_SERVER_ERROR"},
    status.HTTP_501_NOT_IMPLEMENTED: {"description": "NOT_IMPLEMENTED"},
}


# noinspection PyShadowingNames,PyUnusedLocal
@asynccontextmanager
async def lifespan(app: FastAPI):
    """start-up/shutdown処理定義

    Notes: @app.on_event()は、deprecatedとなっている
    """
    # noinspection PyUnresolvedReferences
    logger.info(F"Start-up Event:{version=}\t{root_path=}\t{app.docs_url=}")
    logger.debug(F"{ServerConfig.show_config()=}")
    yield
    logger.info("Shut-down Event")


# nginx設定に併せて、root_pathを設定する
root_path = ServerConfig.api_prefix
app = FastAPI(title=title, description=description, version=version, lifespan=lifespan, responses=responses,
              root_path=root_path)
# -------------------------------------------------
#  CORS定義
# -------------------------------------------------
origins = ["*"]  # Allow all origin
"""
origins = [
    "http://localhost",
    "http://localhost:8080",
]
"""
# noinspection PyTypeChecker
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,  # Allow all origin
    allow_credentials=True,  # Allow cookies
    allow_methods=["*"],  # Allow all method
    allow_headers=["*"],
)


# -------------------------------------------------
#  エンドポイント
# -------------------------------------------------
@app.get("/", summary="Swagger UIへのリダイレクト", include_in_schema=False)
def redirect():
    """Swagger UIへのリダイレクト処理"""
    url = F"{root_path}/docs"
    logger.info(F"Redirect to:{url}")
    return RedirectResponse(url=url)


@app.get("/ping", summary="ヘルスチェック")
def ping(req: Request):
    """### サーバーのヘルスチェック"""
    # noinspection PyProtectedMember
    res = {
        "platform": platform.platform(),
        "method": req.method,
        "url": req.url._url,
        "base_url": req.base_url._url,
        "client": F"{req.client}",
    }
    # ヘルスチェック用に頻繁にアクセスされるため、ログは省略する
    return res


# -------------------------------------------------
# API Router & Admin APP追加
# -------------------------------------------------
app.include_router(router_server)
app.include_router(router_file)

# 管理者用サブアプリのマウント
app.mount(path="/admin", app=app_admin)

# -------------------------------------------------
#  コマンドラインからのサーバ起動エントリ
# -------------------------------------------------
if __name__ == '__main__':
    import uvicorn

    # 実行ファイル名から拡張子を除いたファイル名を取得し、appの起動名を生成する
    name = os.path.splitext(os.path.basename(__file__))[0]
    app_name = F"{name}:app"
    port = ServerConfig.api_port
    host = "0.0.0.0"
    if is_windows_platform():
        host = "localhost"
    logger.info(F"uvicorn.run(app={app_name},{host=},{port=}) on {platform.system()=}")
    uvicorn.run(app=app_name, host=host, port=port, reload=True)
