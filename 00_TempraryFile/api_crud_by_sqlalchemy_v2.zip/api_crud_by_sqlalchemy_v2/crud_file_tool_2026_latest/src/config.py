"""
概要: Configuration定義
更新: 2026/02/12
"""

# 標準ライブラリ
import os
# 拡張ライブラリ
from dotenv import load_dotenv

# ---------------------------------------------
#  一般設定
# ---------------------------------------------
# .envファイルからシークレット定義の読み込み
load_dotenv()
_top_dir = "out_tool"
VER = os.getenv("VER")


class ServerConfig:
    # APIサーバ情報
    api_prefix = os.getenv("API_PREFIX").replace("vx", VER)
    api_port = int(os.getenv("API_PORT"))
    version = F"{VER}.{os.getenv("MINOR_VERSION")}"
    production_mode = True if os.getenv("PRODUCTION_MODE") == "1" else False  # True: 本番運用 / False:非本番

    # ロギング設定
    log_level = "TRACE"  # "TRACE" | "DEBUG" | "INFO"
    if production_mode:
        log_level = "INFO"  # "TRACE" | "DEBUG" | "INFO"
    log_dir = os.path.join(_top_dir, "logs")  # ログファイル用ディレクトリ
    log_file = os.path.join(log_dir, "server.log")  # ロギングファイル名

    # 各種ディレクトリ設定
    upload_dir = os.path.join(_top_dir, "upload")  # 汎用のアップロードファイルの保存用ィレクトリ
    temp_dir = os.path.join(_top_dir, "temp")  # ワークファイル用ディレクトリ

    @classmethod
    def show_config(cls) -> dict:
        """コンフィギュレーション情報の表示"""
        api_info = {
            "production_mode": cls.production_mode,
            "version": cls.version,
            "api_prefix": cls.api_prefix,
            "api_port": cls.api_port,
        }
        log_info = {
            "log_level": cls.log_level,
            "log_dir": cls.log_dir,
            "log_file": cls.log_file,
        }
        dir_info = {
            "temp_dir": cls.temp_dir,
            "upload_dir": cls.upload_dir,
        }
        res = {
            "api_info": api_info,
            "log_info": log_info,
            "dir_info": dir_info,
        }
        return res


# ---------------------------------------------
#  DB関連の定数の設定
# ---------------------------------------------
class DBConfig:
    # 定数定義:DBのStringタイプの最大文字列数定義(APIパラメータの最大文字列数も同じ)
    max_length = 256  # 通常文字列の最大レコードサイズ
    max_length_l = 1024  # ロング文字列の最大レコードサイズ

    # DBの実行用パラメータ定義
    db_mode = int(os.getenv("DB_MODE", default=0))
    # DBログのエコーモードの設定( True:echo On / False: echo OFF)
    echo_mode = True if os.getenv("ECHO_MODE", default=0) == "1" else False
    _db_name = os.getenv("DB_NAME").replace("vx", VER)

    if db_mode == 0:
        # SQLite3 DB利用
        db_path = os.path.join(_top_dir, "sqlite_db")  # DBファイル格納先
        db_uri = F"sqlite:///{db_path}/{_db_name}"
    else:
        # postgresql　or AWS postgresql用のエンジン設定
        db_path = ""
        _db_user = os.getenv("DB_USER")
        _db_pwd = os.getenv("DB_PWD")
        _db_host = os.getenv("DB_HOST", default="localhost")
        if db_mode == 2:
            # AWS postgresql用DB
            _db_host = os.getenv("DB_AWS_HOST")
        _db_port = 5432  # postgresqlのデフォルトポート番号
        db_uri = F"postgresql://{_db_user}:{_db_pwd}@{_db_host}:{_db_port}/{_db_name}"

    @classmethod
    def show_config(cls) -> dict:
        """コンフィギュレーション情報の表示"""
        res = {
            "max_length": cls.max_length,
            "max_length_l": cls.max_length_l,
            "db_mode": cls.db_mode,
            "echo_mode ": cls.echo_mode,
            "db_path": cls.db_path,
            "db_uri": cls.db_uri,
        }
        return res
