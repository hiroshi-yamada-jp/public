"""
概要: File model Helper
更新: 2026/2/18
"""

# 標準ライブラリ
from __future__ import annotations
from typing import Any
from pathlib import Path
import shutil
# 拡張ライブラリ
import polars as pl
from fastapi import UploadFile
# プライベートライブラリ
from db_crud.crud_file import FileModel
from config import ServerConfig
from schema.schema_file import FileAttribute, FileCategory
from common.lib_pl import (byte2text, byte2json, byte2df, byte2text_list, byte2csv_text)


# -----------------------------------------------
#  ヘルパー関数定義
# -----------------------------------------------
class HelperFile:
    """ファイルモデル用ヘルパー"""

    def __init__(self, file_model: FileModel):
        """コンストラクタ"""
        self.__file_model = file_model
        self.__file_body = file_model.file_body
        self.__content_type = file_model.attribute.get("content_type")

    def __is_valid_mime_type(self, support_mime_type: list[str]) -> bool:
        """ファイルが指定のMIME TYPEに属するか判定する"""
        res = any(mime_type in self.__content_type for mime_type in support_mime_type)
        return res

    def is_read_only(self) -> bool:
        return self.__file_model.read_only

    def get_contents_type(self) -> str:
        """ファイル属性に設定されたコンテンツタイプを取得する"""
        return self.__content_type

    def get_file_path(self) -> Path:
        """現ファイルモデルに登録されているファイルのファイルパスを返す"""
        return Path(self.__file_model.attribute.get("file_path")).resolve()

    def remove_upload_file(self) -> None:
        """現ファイルモデルに登録されているファイルが所定ディレクトリに存在すれば、削除する"""
        out_file = self.get_file_path()
        if out_file.is_file():
            out_file.unlink()

    def file_body2text(self, max_lines: int = 0) -> str | None:
        """ファイル内容(バイナリ)をテキスト形式に変換する"""
        return byte2text(self.__file_body, max_lines=max_lines)

    def file_body2text_list(self, max_lines: int = 0) -> list | None:
        """ファイル内容(バイナリ)を行単位のテキストリスト形式に変換する"""
        return byte2text_list(self.__file_body, max_lines=max_lines)

    def file_body2json(self) -> Any:
        """ファイル内容(バイナリ)をJSONデータ(Pythonオブジェクト)に変換する """
        return byte2json(self.__file_body)

    def file_body2df(self, max_lines: int = 0) -> pl.DataFrame | None:
        """ファイル内容(バイナリ)をデータフレーム形式に変換する"""
        return byte2df(self.__file_body, max_lines=max_lines)

    def file_body2csv_text(self, max_lines: int = 0) -> str | None:
        """ファイル内容(バイナリ)をCSV文字列に変換する"""
        return byte2csv_text(self.__file_body, max_lines=max_lines)

    def get_download_file(self) -> Path:
        """ダウンロード用のファイルパスを返す（アップロードのファイルパスと同じ)"""
        out_file_path = Path(self.__file_model.attribute.get("file_path"))
        if not out_file_path.is_file():
            # ファイルがなければ、再作成する
            with open(out_file_path, "wb") as of:
                of.write(self.__file_body)
        return out_file_path


class HelperFileRegister:
    """ファイル登録用ヘルパー"""

    def __init__(self, file: UploadFile, file_category: FileCategory) -> None:
        """コンストラクタ

        Args:
            file: アップロードするファイル
            file_category: アップロードするファイルカテゴリ
        """
        upload_dir = ServerConfig.upload_dir
        assert Path(upload_dir).is_dir(), F"Directory not found:{upload_dir}"
        self.__file_path = Path(upload_dir).joinpath(file.filename)
        self.__file = file
        self.__file_category = file_category

    def get_file_attribute(self) -> FileAttribute:
        """ファイル属性を設定する"""
        res = FileAttribute(
            filename=self.__file.filename,
            content_type=self.__file.content_type,
            size=self.__file.size,
            file_path=str(self.__file_path),
        )
        return res

    def __is_valid_mime_type(self, support_mime_type: list[str]) -> bool:
        """ファイルが指定のMIME TYPEに属するか判定する"""
        contents_type = self.__file.content_type
        return any(mime_type in contents_type for mime_type in support_mime_type)

    def is_valid_file_category(self) -> bool:
        """ファイル登録内容が指定カテゴリのファイル属性に属するかMIME TYPEで判定する

        Returns:
            bool: True:OK / False: 不正形式
        """
        match self.__file_category:
            case FileCategory.TEXT:
                return self.__is_valid_mime_type(support_mime_type=["text", "plane"])

            case FileCategory.CSV:
                return self.__is_valid_mime_type(support_mime_type=["csv"])

            case FileCategory.JSON:
                return self.__is_valid_mime_type(support_mime_type=["json"])

            case FileCategory.UNKNOWN:
                return True

    def create_upload_file(self):
        """アップロードファイルを所定ディレクトリ内にファイルとして作成し、ファイル内容を読み込む"""
        with open(self.__file_path, "wb") as of:
            shutil.copyfileobj(self.__file.file, of)
        with open(self.__file_path, "rb") as f:
            file_body = f.read()
        return file_body
