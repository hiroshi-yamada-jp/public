"""
概要: polars dataframe用のライブラリ + バイト文字列変換ライブラリ
更新: 2026/2/19
"""
# 標準ライブラリ
from __future__ import annotations
import io
import json
from typing import Any
# 拡張ライブラリ
import polars as pl


# ------------------------------
#  byte文字列からの各種変換
# ------------------------------
def byte2str(byte_str: bytes, out_encoding: str = "utf_8") -> str | None:
    """バイト文字列を指定エンコードの文字列に変換する

    Args:
        byte_str: バイト文字列
        out_encoding: str = "utf_8"
    Returns:
        str:出力文字列 / None: 変換不能
    """
    support_encodings = ["utf_8_sig", "cp932"]
    for encoding in support_encodings:
        try:
            # Byte文字列を指定エンコードででコード後に指定エンコードに再変換する
            encoded_str = byte_str.decode(encoding=encoding).encode(out_encoding).decode(out_encoding)
        except (UnicodeDecodeError, UnicodeEncodeError):
            continue
        else:
            return encoded_str
    return None
    # raise ValueError("Unsupported encoding")


def byte2text_list(byte_str: bytes, *, max_lines: int = 0) -> list[str] | None:
    """バイト文字列をテキストリストに変換する

    Args:
        byte_str: バイト文字列
        max_lines: 先頭行から取得する最大行数 (0の場合、全行数を示す)
    Returns:
        list[str]:変換結果 / None: 変換不能
    """
    if (text_content := byte2str(byte_str)) is None:
        return None
    text_list = text_content.splitlines()
    if 0 < max_lines <= len(text_list):
        return text_list[0:max_lines]
    else:
        return text_list


def byte2text(byte_str: bytes, *, max_lines: int = 0) -> str | None:
    """バイト文字列をテキストに変換する

    Args:
        byte_str: バイト文字列
        max_lines: 先頭行から取得する最大行数 (0の場合、全行数を示す)
    Returns:
        list[str]:変換結果 / None: 変換不能
    """
    if max_lines == 0:
        return byte2str(byte_str)
    # 指定行数のテキストを抽出するため一度テキストリストに変換してから、元のテキスト列に戻す
    if (text_list := byte2text_list(byte_str, max_lines=max_lines)) is None:
        return None
    return '\n'.join(text_list)


def byte2df(byte_str: bytes, *, max_lines: int = 0) -> pl.DataFrame | None:
    """バイト文字列をデータフレームに変換する

    Args:
        byte_str: バイト文字列
        max_lines: 先頭行から取得する最大行数 (0の場合、全行数を示す)
    Returns:
        変換結果 / None: 変換不能
    """
    if (text_content := byte2str(byte_str)) is None:
        return None
    df_res = pl.read_csv(source=io.StringIO(text_content))
    if 0 < max_lines <= len(df_res):
        return df_res.head(max_lines)
    else:
        return df_res


def byte2csv_text(byte_str: bytes, *, max_lines: int = 0) -> str | None:
    """バイト文字列をCSVテキストに変換する

    Args:
        byte_str: バイト文字列
        max_lines: 先頭行から取得する最大行数 (0の場合、全行数を示す)
    Returns:
        str:変換結果 / None: 変換不能
    """
    if (df := byte2df(byte_str, max_lines=max_lines)) is None:
        return None
    # データフレームをCSVテキストとして出力
    return df.write_csv(file=None)


def byte2json(byte_str: bytes) -> Any | None:
    """バイト文字列をJSONデータ(Pythonオブジェクト)に変換する

    Args:
        byte_str: バイト文字列
    Returns:
        Any:Pythonオブジェクトへの変換結果 / None: 変換不能
    """
    if (text_content := byte2str(byte_str)) is None:
        return None
    return json.loads(text_content)


# ------------------------------
#  dfへの変換/dfからの変換
# ------------------------------
def csv_string2df(csv_string: str) -> pl.DataFrame:
    """CSV文字列をデータフレームに変換する"""
    return pl.read_csv(source=io.StringIO(csv_string))


def df2csv_string(df: pl.DataFrame) -> str:
    """データフレームをCSV文字列に変換する"""
    return df.write_csv(file=None)


def csv_file2df(file_path: str, encoding: str = "utf_8") -> pl.DataFrame:
    """CSVファイルをデータフレームに変換する"""
    return pl.read_csv(source=file_path, encoding=encoding)


def df2csv_file(df: pl.DataFrame, file_path: str) -> None:
    """データフレームをCSVファイルに保存する"""
    df.write_csv(file=file_path)


def df2dict(df: pl.DataFrame) -> list[dict]:
    """データフレームを辞書のリストに変換する

    Args:
        df: 対象のDataFrame
    Returns:
        list:変換結果 例: [{'A': 1, 'B': 'x'}, {'A': 2, 'B': 'y'}, {'A': 3, 'B': 'z'}]
    """
    return df.to_dicts()


def df2list(df: pl.Series, col: str) -> list:
    """データフレームの指定列をリストに変換する

    Args:
        df: 対象のDataFrame
        col: 抽出対象の列名 例: "C1"
    Returns:
        list: 変換結果 例: [1, 2, 3]
    """
    return df[col].to_list()


def df_diff(df1: pl.DataFrame, df2: pl.DataFrame, id_col: str = "") -> list[dict]:
    """2つのデータフレームの差分を行・カラム単位で比較し、変更内容を返す。

    Args:
        df1: 変更前のデータフレーム
        df2: 変更後のデータフレーム
        id_col: 変更行番号と一緒に出力するID情報のラベル名

    Returns:
        list of dicts: 変更を検知した行とカラム情報のリスト
            各要素は {
                'row_idx': int,
                "id: int | str
                'src1': dict (カラム名: 元の値),
                'src2': dict (カラム名: 変更後の値)
            }
    Notes:
        - ヘッダ行の内容が異なる場合、エラーとする。
        - データフレームの行数が異なる場合、エラーとする。
        - 差分は行番号と変更されたカラム内容を出力する
        - 行番号情報は1からカウントする
        - IDカラムデータ名が有効でない場合、IDカラムは有効データを設定しない
    """
    # ヘッダ行のカラム名を比較
    if list(df1.columns) != list(df2.columns):
        raise ValueError("CSVデータのヘッダ不一致:")
    # 行数の比較
    if len(df1) != len(df2):
        raise ValueError(F"CSVデータの行数不一致:{len(df1)=}\t{len(df2)=}")

    diffs = []
    for i in range(len(df1)):
        row1 = df1[i]
        row2 = df2[i]
        # 行単位で比較し、内容が異なる場合、カラム単位で検査
        if not row1.equals(row2):
            id_data = "NA"
            if id_col and id_col in df1.columns:
                id_data = row1[id_col].to_list()[0]
            # 全カラムのデータ比較
            for col in df1.columns:
                # 各行の現在のカラム内容を取得
                val1 = row1[col].item()
                val2 = row2[col].item()
                # 値が異なる場合に差分リストに追加
                if val1 != val2:
                    change_data = {
                        '(No)': i + 1,
                        'ID': id_data,
                        col: F"{val1} --> {val2}",
                    }
                    diffs.append(change_data)
    return diffs

