"""
概要: Directory library
更新: 2026/2/16
"""

# 標準ライブラリ
from __future__ import annotations
from pathlib import Path
import shutil


def _get_dir_path(target_dir: str) -> Path:
    return Path(target_dir).resolve(strict=False)


def make_empty_directory(target_dir: str) -> None:
    """空ディレクトリを作成する。指定ディレクトリが存在する場合、ディレクトリの中身を削除する

    Args:
        target_dir: 対象のディレクトリパス（例: dir1/dire2
    """
    dir_path = _get_dir_path(target_dir)
    if dir_path.is_dir():
        shutil.rmtree(target_dir)
    dir_path.mkdir(parents=True, exist_ok=True)


def get_filename_in_directory(target_dir: str, pattern: str = "*") -> list[str] | None:
    """指定ディレクトリ直下に存在するファイル名一覧を取得する

    Args:
        target_dir: 対象ディレクトリパス
        pattern: 一致するファイル名パターン
    Returns:
        list[str]: 指定ディレクトリ内のファイル名一覧 / None: 指定ディレクトリが存在しない場合
    """
    dir_path = _get_dir_path(target_dir)

    if not dir_path.is_dir():
        return None
    # glob でパターンに一致するファイル名一覧を取得
    return [file_path.name for file_path in dir_path.glob(pattern=pattern) if file_path.is_file()]


def get_file_in_directory(target_dir: str, pattern: str = "*") -> list[Path] | None:
    """指定ディレクトリ直下に存在するファイルパス一覧を取得する

    Args:
        target_dir: 対象ディレクトリパス
        pattern: 一致するファイル名パターン
    Returns:
        list[Path] : 指定ディレクトリ内のファイルパス一覧 / None: 指定ディレクトリが存在しない場合
    """
    dir_path = _get_dir_path(target_dir)

    if not dir_path.is_dir():
        return None
    # glob でパターンに一致するファイル名一覧を取得
    return [file_path for file_path in dir_path.glob(pattern=pattern) if file_path.is_file()]
