"""
概要: 各種検査ライブラリ
更新: 2026/02/18
"""
# 標準ライブラリ
from __future__ import annotations


# ------------------------------
#  検査用ライブラリ
# ------------------------------

def get_effective_string(s_in: str, min_len: int = 1) -> str:
    """入力文字列を検査し、有効文字列の抽出。文字列長が規定未満の場合、エクセプションを返す。

    Args:
        s_in: 入力文字列
        min_len: 最小の有効文字列長
    Returns:
        str: 有効文字列
    Exceptions:
        TypeError: 入力内容が文字列でない場合
        ValueError: 入力文字列が有効文字列長未満の場合
    """
    if not isinstance(s_in, str):
        raise TypeError(F"Invalid type:{type(s_in)} ")
    if len(s_in.strip()) < min_len:
        raise ValueError(F"Invalid or too short parameter:{repr(s_in)} ")
    return s_in.strip()


def check_str(val: str | None, *, valid_values: list[str | None], allow_none: bool = False, error_prefix=None) -> bool:
    """入力データが指定リスト内のどれかに一致するか検査する

    Args:　略(get_error_for_str()と同じ)

    Returns:
        bool: True: OK / False: NG(不正値)
    """
    err_message = get_error_for_str(val, valid_values=valid_values, allow_none=allow_none, error_prefix=error_prefix)
    return True if err_message is None else False


def check_int(val: int | str | None, *, min_val: int, max_val: int | None = None, allow_none: bool = False) -> bool:
    """入力データが指定範囲内の整数か検査する

    Args:　略(get_error_for_int()と同じ)

    Returns:
        bool: True: OK / False: NG(不正な値)
    """
    err_message = get_error_for_int(val, min_val=min_val, max_val=max_val, allow_none=allow_none)
    return True if err_message is None else False


def get_error_for_str(val: str | None, *, valid_values: list[str | None], allow_none: bool = False,
                      error_prefix=None) -> str | None:
    """入力データが指定文字列群に一致するか検査し、エラーの場合、エラー内容を示す文字列を返す

    Args:
        val: 入力データ(文字列またはNone)
        valid_values: 許容文字列リスト: 例: ["READY","NOT_READY","UNKNOWN", None]
        allow_none: True:Noneを許容 / False:Noneを許容しない
        error_prefix: None:なし / str:指定文字列を含む場合、OKとする
    Returns:
        None: OK / str: NG(エラー原因を示す文字列)
    Notes:
        ok_valuesが空リストの場合、全ての文字列をOKとする
        error_prefixが有効な場合、error_prefix文字列を含む場合、OKとする
    """
    ok = None
    error = F"不正値({val=})"
    # Noneを許容する場合
    if val is None and allow_none:
        return ok
    if not isinstance(val, str):
        error = F"不正データ形式({val=})"
        return error
    # 指定文字を限定しない場合
    if len(valid_values) == 0:
        return ok
    # 指定文字列がerror_prefix文字列を含む場合
    if error_prefix is not None and error_prefix in val:
        return ok
    if val in valid_values:
        return ok
    return error


def get_error_for_int(val: int | str | None, *, min_val: int, max_val: int | None = None,
                      allow_none: bool = False) -> str | None:
    """入力データが指定範囲内の整数か検査し、エラーの場合、エラー内容を示す文字列を返す

    Args:
        val: 入力データ(整数、整数文字列、None)
        min_val: 最小値
        max_val: 最大値 | None  Noneの場合は、最大値指定無効
        allow_none: True:Noneを許容 / False:Noneを許容しない
    Returns:
        None:OK / str: エラー原因を示す文字列
    """
    ok = None
    error = F"不正値({val=})"
    # Noneを許容する場合
    if val is None and allow_none:
        return ok
    # 整数変換可能か検査する
    try:
        val = int(val)
    except (ValueError, TypeError):
        error = F"不正形式({val=}:{type(val)})"
        return error
    if val < min_val:
        return error
    if max_val is None or val <= max_val:
        return ok
    return error
