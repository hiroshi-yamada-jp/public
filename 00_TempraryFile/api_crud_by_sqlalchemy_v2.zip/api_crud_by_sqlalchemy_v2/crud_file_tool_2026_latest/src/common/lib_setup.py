"""
概要: Initial setup Library
更新: 2026/2/18
"""

# 標準ライブラリ
from __future__ import annotations
from pathlib import Path
from sys import stdout
# 拡張ライブラリ
from loguru import logger
from config import ServerConfig
import platform


def is_windows_platform() -> bool:
    """稼働環境がwindows PFか判定する"""
    return True if "windows" in platform.system().lower() else False


def setup_server_directory() -> None:
    """サーバで利用する各ディレクトリをセットアップする
    """
    dirs = [ServerConfig.log_dir, ServerConfig.temp_dir, ServerConfig.upload_dir]
    for dir_path in dirs:
        if not Path(dir_path).is_dir():
            Path(dir_path).mkdir(parents=True, exist_ok=True)


def setup_loguru(log_level: str, *, log_file: str = "", rotation: str = "7 days", retention: str = "21 days") -> None:
    """ロギング情報の初期設定

    Args:
        log_level: ログレベルの設定 ("TRACE" | "DEBUG" | "INFO" )
        log_file: ログファイルの出力パス (空白文字の場合、ログファイル出力は無効となる)
        rotation: ログファイルのローテーション期間( "00:00" | "3 days" | "7 days")
        retention: ログファイルの保存期間  ( "7 days" | "12 days"| "21 days")
    Returns:
        None
    """
    logger.remove()  # デフォルトのログ設定をクリア
    # 出力フォーマット定義:レベル・モジュール・関数部はレベルに応じた色、メッセージは装飾なしに設定した例
    fmt1 = "<level>[SVR:{level}][{time:YYYY-MM-DD HH:mm:ss.SSSS}]:[{module}:{function}:{line}]:{message}</level>"
    # ディスプレイ出力用の設定
    logger.add(stdout, format=fmt1, level=log_level)
    # ファイル出力用設定：毎日指定時刻にローテートしてn世代分持つ、初期ディレクトリは自動作成される
    if log_file:
        logger.add(log_file, rotation=rotation, retention=retention, format=fmt1, level=log_level)
