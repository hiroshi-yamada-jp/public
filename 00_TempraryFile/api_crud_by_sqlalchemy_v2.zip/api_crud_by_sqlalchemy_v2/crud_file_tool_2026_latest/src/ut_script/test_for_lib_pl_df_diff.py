"""
概要: lib_pl内のCSV比較関数のテストコード
結果: OK 2025/11/28
"""

# 標準ライブラリ
from __future__ import annotations
from pprint import pprint
# 拡張ライブラリ
import polars as pl
# テスト対象ソース
from common.lib_pl import df_diff

N = 5
# データ内容
data1 = {
    "ID": [i + 1 for i in range(N)],
    "名前": ["名前A", "名前B", "名前C", "名前D", "名前E"],
    "年齢": [(i + 1) * 10 for i in range(N)],
    "血液型": ["A"] * N,
}

data2 = {
    "ID": [i + 1 for i in range(N)],
    "名前": ["名前A", "名前B-up", "名前C", "名前D-up", "名前E"],
    "年齢": [10, 22, 30, 44, 50],
    "血液型": ["A", "AB", "O", "B", "A"],
}


# テスト実行
def test_csv_diff_with_changes():
    df1 = pl.DataFrame(data1, strict=False)
    df2 = pl.DataFrame(data2, strict=False)
    print(F"{df1=}\n{df2=}")

    res = df_diff(df1, df2)
    print(F"df_diff(df1, df2)={type(res)}")
    pprint(res, width=120)


# 実行
if __name__ == '__main__':
    test_csv_diff_with_changes()
