"""
概要: ライブラリのテスト
結果: OK @2026/2/13
"""

# 標準ライブラリ
from __future__ import annotations
# テスト対象
from common.lib_check import get_effective_string


# -------------------------------
#  テスト用関数
# -------------------------------
def test01():
    print("\n== 1. get_effective_string()")
    test_list = ["", " 　", "   a b  ", "\t", "Valid_name ", 10]
    for str1 in test_list:
        try:
            print(F"\n== {str1=}\t{type(str1)}")
            res = get_effective_string(s_in=str1)
            print(F"get_effective_string(s_in={repr(str1)})={repr(res)}\t{type(res)}")
            res = get_effective_string(s_in=str1, min_len=0)
            print(F"get_effective_string(s_in={repr(str1)}, min_len=0)={repr(res)}\t{type(res)}")
        except ValueError:
            print(F"ValueError: get_effective_string(s_in={repr(str1)})\t{type(str1)}")
        except TypeError:
            print(F"TypeError: get_effective_string(s_in={repr(str1)})\t{type(str1)}")


# ---------------------------------------------
#  起動エントリ
# ---------------------------------------------
if __name__ == '__main__':
    test01()
