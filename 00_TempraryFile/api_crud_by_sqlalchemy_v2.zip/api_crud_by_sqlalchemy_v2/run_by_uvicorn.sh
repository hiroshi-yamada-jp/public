#!/bin/bash
# Function: Run API server by uvicorn
# Note:
#  - Change directory name according to you environment
#

# 変数定義
HOME_DIR="/home/hy"
VENV_DIR="$HOME_DIR/venv/bin"  # 仮想環境のディレクトリ
echo "== Activate venv"
source "$VENV_DIR/activate"
sleep 1

APP_DIR="$HOME_DIR/xxx/src" # Python環境のディレクトリ
APP_MODULE="main:app"
echo "=== Change directory ($APP_DIR) and Run API server by uvicorn"
cd "$APP_DIR"
exec uvicorn "$APP_MODULE" --host 0.0.0.0 --port 8000 &
